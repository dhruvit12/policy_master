<?php include 'header.php';

include 'navbar.php';
include 'top_navbar.php';
include 'dashboard/dashboard.php';
include 'footer.php';
?>