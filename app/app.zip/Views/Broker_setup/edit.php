<br><br><br><br>
<div class="container">
<div class="modal-dialog" role="document">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Details</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <form role="form" method="post" action="<?=base_url('Broker_setup/update_success')?>">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="">Broker Name:</label>
              <input type="hidden" name="id" value="<?php echo $data['id'];?>">
              <input type="text" name="broker_name" class="form-control" value="<?php echo $data['broker_name'];?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="">Broker Id:</label>
              <input type="text" class="form-control" name="Broker_id" disabled="" value="<?php echo $data['broker_id'];?>">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 ">
            <div class="form-group">
             <label for="">Address:</label>
             <textarea name="address" class="form-control"><?php echo $data['address'];?></textarea>
           </div>
         </div>
      </div>
       <div class="row">
          <div class="col-md-6 ">
            <div class="form-group">
             <label for="">Telephone No:</label>
             <input type="text" name="telephone" class="form-control" value="<?php echo $data['telephone'];?>">
             </div>
         </div>
           <div class="col-md-6 ">
            <div class="form-group">
             <label for="">Email:</label>
             <input type="email" name="email" class="form-control " value="<?php echo $data['email'];?>">
             </div>
         </div>
      </div>
       
      <div class="modal-footer">
         <button type="submit" class="btn btn-primary">Save</button>
        <a href="<?php echo base_url('Broker_setup')?>" class="btn btn-secondary">Close</a>
      </div>
    </form>
  </div>
</div>
</div>