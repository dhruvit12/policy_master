<!-- Content Wrapper. Contains page content -->
<?php
  $session = session();
  $userdata = $session->get('userdata');
 ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

    </section>
    <!-- Main content -->

    <section class="content">
        <div class="col-md-12">
            <!-- form start -->
            <h5>Email Cover Notes</h5>
            <form method="post" action="">
                <div class="row">
                  <div class="card width-full">
                    <div class="card-body">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="row">
                              <div class="col-md-4">
                                <div class="form-group">
                                  <label for="">Date From</label>
                                  <input type="date"  name="date_from" value="" class="form-control">
                                </div>
                              </div>
                              <div class="col-md-4">
                                <div class="form-group">
                                  <label for="">- to -</label>
                                  <input type="date"  name="date_from" value="" class="form-control">
                                </div>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col-md-12">
                                <div class="form-check">
                                  <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                                  <label class="form-check-label" for="defaultCheck1">
                                    Send to All Insurance Companies
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="exampleFormControlSelect1">Select Insurer :</label>
                              <select class="form-control select2" name="fk_insurance_company_id" id="insurance-company-name" required="true">
                                <option value="" selected="true" disabled="true"> Select Insurer</option>
                                <?php foreach ($insurancecompany as $key): ?>
                                  <option value="<?= $key['id'] ?>"><?= $key['insurance_company'] ?></option>
                                <?php endforeach; ?>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="exampleFormControlSelect1">E-mail :</label>
                              <textarea name="name" class="form-control" rows="3"></textarea>
                              <small>Use: Email separator ","</small>
                            </div>
                          </div>
                        </div>
                        <hr/>
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="exampleFormControlSelect1">Subject  :</label>
                              <input type="text" class="form-control" name="" value="">
                            </div>
                            <div class="form-group">
                              <label for="exampleFormControlSelect1">Body :</label>
                              <textarea name="name" class="form-control" rows="6"></textarea>
                            </div>
                          </div>
                        </div>
                    </div>
                    <div class="card-footer align-end">
                      <button type="submit" class="btn btn-success">Send</button>
                      <a href="<?=base_url() ?>" class="btn btn-secondary">Exit</a>
                    </div>
                  </div>
                </div>
            </form>
        </div>
    </section>
</div>

<!-- Modal Start Here -->
<script type="text/javascript">
$(document).ready(function(){
});
</script>
