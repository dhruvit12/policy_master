 <div class="content-wrapper"><br><br>
 <div class="container">
   <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Setup Clauses</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <form role="form" method="post" action="<?=base_url('Setup_clauses/update')?>">
        <div class="row">
          <div class="col-md-7">
            <div class="form-group">
              <label for="">Type:</label>
              <input type="hidden" name="id" value="<?php  echo $single['id'];?>">
              <select class="form-control" name="type">
              
                <?php  foreach($setup as $set){ ?> 
                  <option value="<?php echo $set['id'];?>" <?php if($single['type']==$set['id']) { echo "selected"; } ?>><?php echo $set['type'];?></option><?php  } ?></select>
                </div>
              </div>

            </div>
            <div class="row">
              <div class="col-md-12 ">
                <div class="form-group">
                 <label for="">Name:</label>
                 <input type="text" name="name" class="form-control" value="<?php echo $single['name'];?>">
               </div>
             </div>
           </div>
           <div class="row">
            <div class="col-md-12 ">
              <div class="form-group">
               <label for="">Description:</label>
               <textarea name="description" class="summernote-textarea" class="form-control"><?php echo $single['description'];?></textarea>
             </div>
           </div>

         </div>
         <div class="modal-footer">
          <a href="<?php echo base_url('Setup_clauses')?>" class="btn btn-secondary">close</a>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
  <script type="text/javascript">
      $(document).ready(function() {
            $('.summernote-textarea').summernote({
            height: 200,
            codemirror: {
              theme: 'monokai'
            }
          });
        });
  </script>