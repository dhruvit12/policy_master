<!-- Content Wrapper. Contains page content -->
<?php
$session = session();
$userdata = $session->get('userdata');
?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <span>Endorsement </span>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Endorsement</a></li>
              <li class="breadcrumb-item active">List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <div class="collapse" id="collapseExample">
        <div class="card-body">
          <form action="<?=base_url('endorsement/search_endorsement')?>" method="post">
            <div class="form-group row">
              <label for="inputEmail3" class="col-sm-2 col-form-label">Client Name</label>
              <div class="col-sm-2">
                <input type="text" class="form-control" id="client-name" name="client_name" placeholder="Client Name" value="<?php if(!empty($search_data['client_name'])){ echo $search_data['client_name']; } ?>">
              </div>
              <label for="inputEmail3" class="col-sm-2 col-form-label">Quote No</label>
              <div class="col-sm-2">
                <input type="text" class="form-control" id="quote-no" name="quote_no" placeholder="Quote-no" value="<?php if(!empty($search_data['quote_no'])){ echo $search_data['quote_no']; } ?>">
              </div>
              <label for="inputEmail3" class="col-sm-2 col-form-label">Date From</label>
              <div class="col-sm-2">
                <input type="text" class="form-control" autocomplete="off" id="fromDate" name="date_from"   placeholder="Date from" value="<?php if(!empty($search_data['date_from'])) { echo $search_data['date_from'];} ?>">
              </div>
            </div>
            <div class="form-group row">
            
              <label for="inputEmail3" class="col-sm-2 col-form-label">- To -</label>
              <div class="col-sm-2">
            <input type="text" class="form-control" autocomplete="off" id="toDate"  name="date_to"  placeholder="To" value="<?php if(!empty($search_data['date_to'])) { echo $search_data['date_to'];} ?>">
            </div>
            </div>
            <div class="card-footer d-flex justify-content-center">
              <button type="submit" class="btn btn-success">Get It</button>
            </div>

          </form>
        </div>
    </div>
    <div class="card-body">
     
      <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-sm-4">

        </div>
        <div class="col-sm-8 mb-1">
          <div class="float-sm-right">
            <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
              <i class="fa fa-search"></i>&nbsp;&nbsp;Search
            </a>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addEndorsementModal"><i class="fa fa-plus"></i> Add New</button>
            <a href="" class="btn btn-primary"> Refresh</a>
          </div>
        </div>
      </div>
    </div>
    <div class="card-body">
      <?php $session=session();
              if($msg=$session->getFlashdata('error')):?>
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><?= $msg ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php  endif;
                    if($msg=$session->getFlashdata('update')):?>
                      <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><?= $msg ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php  endif; ?>
      <div class="table-fluide">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Risk Note</th>
              <th>Branch</th>
              <th>Date</th>
              <th>Insured Name</th>
              <th>Cover Information</th>
              <th>Cover Period</th>
              <th>Insurer</th>
              <th>Amount Payable / Amount Received</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          <?php $i=1;if ($list): ?>
            <?php foreach ($list as $key): ?>
          <tr>
              <td class="text-capitalize"><?= $i?></td>
              <td class="text-capitalize"><?= $key['risk_note_no'] ?></td>
              <td class="text-capitalize"><?= $key['branch_name'] ?></td>
              <td class="text-capitalize"><?= date("d-M-y",strtotime($key['date_from'])) ?></td>
              <td class="text-capitalize"><?= $key['client_name'] ?></td>
              <td class="text-capitalize"><?= $key['covering_details'] ?></td>
              <td class="text-capitalize"><?= date("d-M-Y",strtotime($key['date_from'])) ?><br><?= date("d-M-y",strtotime($key['date_to'])) ?></td>
              <td class="text-capitalize"><?= $key['insurance_company'] ?></td>
              <td class="text-capitalize"><?= $key['current_balance'] ?></td>
              <td>
                <?php if ($key['status'] == 0): ?>
                  <a href="#" class="badge badge-danger">pending</a>
                <?php elseif ($key['status'] == 1): ?>
                  <a href="#" class="badge badge-success">Issued</a>
                <?php elseif ($key['status'] == 2): ?>
                  <a href="#" class="badge badge-dark">cancel</a>
                <?php endif; ?>
              </td>
              <td class="project-actions">
                <form method="post" action="<?php echo base_url('endorsement/open_endorsement_model') ?>">
                  <input type="hidden" name="fk_insurance_type_id" value="<?php echo $key['fk_insurance_type_id'];?>">
                  <input type="hidden" name="id" value="<?php echo $key['id'];?>">
                  <button type="submit" class="btn btn-primary btn-xs"><i class="fa fa-tv" aria-hidden="true"></i></button>
                </form>
                <a href="<?php echo base_url('export/endorsement/')?>/<?php echo $key['id'];?>" class="btn btn-info btn-xs print-quotation"><i class="fa fa-print" aria-hidden="true"></i></a>
                <a href="<?php echo base_url('endorsement/cancel_endorsement/')?>/<?php echo $key['id'];?>" class="btn btn-danger btn-xs" onclick="return confirm('Are you sure you want to cancel this endorsement?');"><i class="fa fa-times-circle" aria-hidden="true"></i></a>
              </td>
          </tr>
          <?php $i++;endforeach; ?>
        <?php endif; ?>
          </tbody>
         </table>
      </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="addEndorsementModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">SELECT THE ENDORSEMENT TYPE</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label for="inputClient">Endorsement Type</label>
              <select class="form-control custom-select text-capitalize go-addEndorsement" id="insurance-type" name="insurance-type">
                <option selected disabled>Select one</option>
                <?php foreach ($endorsementType as $key): ?>
                  <option value="<?=$key['id']?>"><?=$key['endorsement_type']?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Exit</button>
          </div>
        </div>
      </div>
    </div>
    </div>




<script type="text/javascript">
$(document).ready(function(){
  $('.go-addEndorsement').change(function() {
    var id = $(this).val();
    window.location.replace("<?= base_url() ?>/endorsement/add_endorsement/"+id);
  });
});
</script>
<script type="text/javascript">
</script>
