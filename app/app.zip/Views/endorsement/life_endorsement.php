<?php
$session = session();
$userdata = $session->get('userdata');
?>
<script>
  function myFunction() {
    var userDateinput= document.getElementById("date_of_birth").value;
    console.log(userDateinput);

     // convert user input value into date object
     var birthDate = new Date(userDateinput);
     console.log(" birthDate"+ birthDate);

   // get difference from current date;
   var difference=Date.now() - birthDate.getTime(); 

   var  ageDate = new Date(difference); 
   var calculatedAge=   Math.abs(ageDate.getUTCFullYear() - 1970);
   $('#age').val(calculatedAge);
 }
</script>
<?php if(!empty($type)) { if($type == 1) {?>
<div class="content-wrapper">
  <section class="content">
    <div class="container-fluide" style="padding:10px;">
      <h5>Endorsement</h5>
      <div class="row">
        <div class="card width-full">
          <div class="card-body">
            <div class="row">
              <div class="col-md-2 d-flex">
                <form class=""   action="<?= base_url('Endorsement/life_endorsement_search') ?>" method="post">
                  <div class="form-group">
                    <label>Risk Note #</label>
                    <input type="text" name="risknote_no" value="<?= isset($postdata['risknote_no'])?$postdata['risknote_no']:'' ?>" class="form-control" style="" >
                  </div>
                  <button type="submit" style="height:max-content;margin:auto;" class="btn btn-info" >Fetch</button>
                </form>
              </div>
              <?php if(!empty($quotation)) { foreach($quotation as $qs) { ?>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Insurance type</label>
                    <select class="form-control" name="insurance_type" disabled="">
                      <?php if(!empty($insuranceType)){ ?>
                        <option value="<?php echo $insuranceType['name'];?>"><?php echo $insuranceType['name'];?></option>
                        <?php }?></select>
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label>Old Premium</label>
                        <input type="text" name="old_premium" class="form-control" >
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label>Period From</label>
                        <input type="date" name="period_from" class="form-control" value="<?php echo $qs['date_from'];?>" >
                      </div>
                    </div>

                    <div class="col-md-2">
                      <div class="form-group">
                        <label>To</label>
                        <input type="date" name="to" class="form-control" value="<?php echo $qs['date_to'];?>" >
                      </div>
                    </div>
                  </div></div>
                </div>
              </div>
            </div>

            <form action="<?php echo base_url('Endorsement/edit_data')?>" method="post">
              <div class="row">
                <div class="card width-full">
                 <div class="card-body">
                   <div class="row">
                     <div class="col-md-4">
                       <div class="form-group">
                         <label>Client Name</label>

                         <input type="text" class="form-control" name="client_name" readonly value="<?php echo $qs['client_name'];?>">
                       </div>

                       <div class="form-group">
                         <label>Insured Name :</label>
                         <input type="text" class="form-control" name="insured_name" readonly value="<?php echo $qs['insured_name'];?>">
                       </div>
                     </div>
                     <div class="col-md-4">
                       <div class="row">
                         <div class="form-group width-full">
                           <label>Insurer</label>
                           <select name="insurance_companyname" id="company_name" class="form-control" disabled="">
                            <option value="<?php echo $qs['insurance_company'];?>"><?php echo $qs['insurance_company'];?></option>
                          </select>

                        </div>
                      </div>
                      <div class="form-group">
                       <label>Address</label>
                       <textarea name="address" class="form-control" rows="2"><?php echo $qs['address'];?></textarea>
                     </div>
                   </div>
                   <div class="col-md-4">
                     <div class="row">
                       <div class="col-md-6">
                         <div class="form-group">
                           <label>Currency</label>
                           <input type="text" class="form-control" name="currency"  readonly <?php echo $qs['ccy'];?>>
                         </div>
                       </div>
                       <div class="col-md-6">
                         <div class="form-group">
                           <label>Branch</label>
                           <input type="text" name="branch_name"  class="form-control" value="<?php echo $qs['branch_name'];?>">
                         </div>
                       </div>
                     </div>
                     <div class="row">
                       <div class="col-sm-5">
                         <div class="form-group">
                           <label>Period From</label>
                           <input type="date" name="date_from" class="form-control" value="<?php echo $qs['date_from'];?>">
                         </div>
                       </div>
                       <div class="col-sm-5">
                         <div class="form-group">
                           <label>To</label>
                           <input type="date" name="date_to" class="form-control" value="<?php echo $qs['date_to'];?>">
                         </div>
                       </div>
                       <div class="col-sm-2">
                         <div class="form-group">
                           <label>Days</label>
                           <input type="text" name="days_count" class="form-control"  value="<?php echo $qs['days_count'];?>">
                         </div>
                       </div>
                     </div>
                   </div>
                 </div>
                 <div class="row">
                   <div class="col-md-6">
                     <div class="form-group">
                       <label>Covering Details</label>
                       <textarea name="covering_details" class="form-control" rows="2"><?php echo $qs['covering_details'];?></textarea>
                     </div>
                     <div class="form-group">
                       <label>Firstloss payee :</label>
                       <input type="text" name="firstlosspayee" class="form-control" value="<?php echo $qs['first_loss_payee'];?>">
                     </div>
                   </div>
                   <div class="col-md-6">
                     <div class="form-group">
                       <label>Description of Risk</label>
                       <textarea name="name" class="form-control" rows="2"><?php echo $qs['description_of_risk'];?></textarea>
                     </div>
                   </div>
                 </div>
                 <div class="row mt-12">
                   <div class="col-md-12 bg-white">
                     <div class="card-header bg-primary">
                       <h3 class="card-title">Insert Panel</h3>
                     </div>
                     <div class="insert-panel-data" style="background-color: #ceea93; padding:8px;">
                       <div class="row mt-4">
                         <div class="col-md-3">
                           <div class="form-group">
                             <label for="">Insurance Class</label>
                             <input type="hidden" name="id" id="id">
                             <select name="insurance_class" id="insurance_class" class="form-control text-capitalize" id="insuranceclass" disabled="">
                                <option value="">standard Rate</option>
                             </select>
                             <input type="hidden" name="quot_id" id="quot_id" value="<?php echo $qs['id'];?>">
                           </div>
                           <div class="form-group">
                             <label for="">Description<span class="text-danger">*</span></label>
                             <textarea  class="form-control" name="description" id="description"><?php echo $liferecord['description'];?></textarea>
                           </div>
                         </div>
                         <div class="col-md-2">
                           <div class="form-group">
                             <label for="">Date of birth</label>
                             <input type="date" class="form-control" name="date_of_birth" id="date_of_birth" onchange="myFunction()" value="<?php echo $liferecord['dob'];?>">
                           </div>
                           <div class="form-group">
                             <label for="">age</label>
                             <input type="text" name="age" id="age" class="form-control" value="<?php echo $liferecord['age'];?>">
                           </div>
                           <div class="form-group">
                             <label for="">Member Add Date </label>
                             <input type="date" name="member_date" id="member_date" class="form-control" value="<?php echo $liferecord['member_add_date'];?>" >
                           </div>
                           <div class="form-group">
                             <label for="">Branch Name </label>
                             <input type="text" name="branch_name" id="branch_name" class="form-control" value="<?php echo $liferecord['branch_name'];?>" >
                           </div>
                           <div class="form-group">
                             <label for="">Monthly Fee</label>
                             <input type="text" name="monthly_fee" id="monthly_fee" class="form-control" value="<?php echo $liferecord['monthly_fees'];?>"  >
                           </div>
                         </div>
                         <div class="col-md-2">
                           <div class="form-group">
                             <label for="">ID Type</label>
                             <input type="text" class="form-control" id="id_type" name="id_type" value="<?php echo $liferecord['id_type'];?>">
                           </div>
                           <div class="form-group">
                             <label for="">ID Number</label>
                             <input type="number" class="form-control" name="id_number" id="id_number" value="<?php echo $liferecord['id_number'];?>">
                           </div>
                           <div class="form-group">
                             <label for="">Primary Member Id</label>
                             <select name="primary_member_id" id="primary_member_id" class="form-control" value="<?php echo $liferecord['primary_member_id'];?>">
                               <option value="1">1</option>
                             </select>
                           </div>
                           <div class="form-group">
                             <label for="">Account number</label>
                             <input type="number" class="form-control" name="account_number" id="account_number" value="<?php echo $liferecord['account_number'];?>">
                           </div>
                           <div class="form-group">
                             <label for="">Transaction date</label>
                             <input type="date" class="form-control" name="transaction_date" id="transaction_date" value="<?php echo $liferecord['transaction_date'];?>">
                           </div>

                         </div>
                         <div class="col-md-2">
                           <div class="form-group">
                             <label for="">Relationship</label>
                             <select name="relationship" id="relationship" tabindex="22" class="form-control">
                              <option value="">Please Select</option>
                              <?php foreach($relationship as $rs){ ?>
                                    <option value="<?php echo $rs['name'];?>" <?php if($rs['name']==$liferecord['relationship']){ echo "selected";} ?>><?php echo $rs['name'];?></option>
                              <?php } ?>

                            </select>
                          </div>
                          <div class="form-group">
                           <label for="">Gender</label>
                           <select name="gender" class="form-control" id="gender">
                              <option disabled="">Please select</option>
                              <option value="male" <?php if($liferecord['gender']=='male') { echo "selected";}?>>male</option>
                              <option value="female" <?php if($liferecord['gender']=='female') { echo "selected";}?>>female</option></select>
                         </div>
                         <div class="form-group">
                           <label for="">Pre Existing condition</label>
                           <textarea name="pre_existing_condition" id="pre_existing_condition" class="form-control"><?php echo $liferecord['pre_existing_condition'];?></textarea>
                         </div>
                       </div>
                       <div class="col-md-2">
                         <div class="form-group">
                           <label for="">Sum_Assured</label>
                           <input type="text" name="sum_insured" class="form-control" id="sum_insured" value="<?php echo $liferecord['sum_assured'];?>">
                         </div>
                         <div class="form-group">
                           <label for=""><span class="bold">Total Premium</span><span style="color: Red"> *</span></label>
                           <input type="text" name="total_premium" class="form-control" id="total_premium" value="<?php echo $liferecord['total_premium'];?>">
                           <input type="hidden" id="id" name="id">
                         </div>
                         <div class="form-group">
                           <input type="button" class="btn btn-primary Insert"  id="insertid" value="Insert">
                           <input type="button" class="btn btn-success Insert"  id="updateid" value="Update">
                         </div>
                       </div>
                     </div>
                   </div>
                   <div class="row">
                     <div class="col-lg-3">
                       <label>Upload Excel File</label>
                       <input type="text" name="Upload_file" class="form-control" disabled="">
                     </div>
                     <div class="col-lg-3">
                       <label></label>
                       <input type="file" name="Upload_file" class="form-control">
                     </div>
                     <div class="col-lg-2">
                       <label></label><br>
                       <input type="button" name="" value="Process File" class="btn btn-primary" disabled="">
                     </div>
                     <div class="col-lg-5">
                       <label></label><br>
                       <a href="#" id="MainContent_btnDwnldTmplt" target="_blank" title="Click here to download Excel Template">Click here to download
                       Excel Template</a>
                     </div>



                   </div>
                   <div class="row">
                    <div class="col-lg-3">
                     <p>Search Criteria</p>
                   </div>
                 </div>
                 <div class="row">

                  <div class="col-md-2" style="border-left: 1px solid black;border-top:1px solid black;border-bottom: 1px solid black; ">
                   <div class="form-group">
                     <label for="">Id</label>
                     <input type="text" name="id" class="form-control" >
                   </div>
                 </div>
                 <div class="col-md-2"  style="border-top:1px solid black;border-bottom: 1px solid black; ">
                   <div class="form-group">
                     <label for="">description</label>
                     <input type="text" name="description" class="form-control" >
                   </div>
                 </div>
                 <div class="col-md-2" style="border-top:1px solid black;border-bottom: 1px solid black; ">
                   <div class="form-group">
                     <label for="">Relationship</label>
                     <input type="text" name="insurer_settlement" class="form-control" >
                   </div>
                 </div>
                 <div class="col-md-6" style="border-top:1px solid black;border-bottom: 1px solid black;border-right: 1px solid black;">
                   <div class="form-group"><br>
                     <input type="button" name="Fetch" value="Fetch" class="btn btn-primary">
                   </div>
                 </div>

               </div>
               <table class="table">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">description</th>
                    <th scope="col">DOB</th>
                    <th scope="col">Age</th>
                    <th scope="col">Id type/Id number</th>
                    <th scope="col">Relationship</th>
                    <th scope="col">Sum Assured</th>
                    <th scope="col">Premium</th>
                    <th scope="col">cancel Amount</th>
                    <th scope="col">Add date</th>
                    <th scope="col">Remove date</th>
                    <th scope="col">status</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody id="insertpaneldata">
                </tbody>
              </table>
              <div class="row">
               <div class="col-md-3">
                 <div class="form-group">
                   <label for="">Commission Rate %</label>
                   <input type="text" name="commission-rate" class="form-control" >
                 </div>
               </div>
               <div class="col-md-3">
                 <div class="form-group">
                   <label for="">Broker Settlement</label>
                   <input type="text" name="broker_settlement" class="form-control" >
                 </div>
               </div>
               <div class="col-md-3">
                 <div class="form-group">
                   <label for="">Insurer Settlement</label>
                   <input type="text" name="insurer_settlement" class="form-control" >
                 </div>
               </div>
               <div class="col-md-3">
                 <div class="form-group">
                   <label for="">Added Premium</label>
                   <input type="text" name="added_premium" class="form-control" >
                 </div>
               </div>
             </div>
             <div class="row">
               <div class="col-md-6">
               </div>
               <div class="col-md-3">
                <div class="form-check">
                 <input class="form-check-input" type="checkbox" value="">
                 <label class="form-check-label"><b>Non-Financial Endorsement</b></label>
               </div>
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Cancelled Premium</label>
                 <input type="text" name="cancelled_premium" class="form-control" >
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
             </div>
             <div class="col-md-3">

             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Total Premium :</label>
                 <input type="text" name="total_premium" class="form-control" >
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
             </div>
             <div class="col-md-3">

             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Other fee</label>
                 <input type="text" name="other_fee" class="form-control" >
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-9">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Insurer Charges</label>
                 <input type="text" name="insurer_charge" class="form-control" >
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-9">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Total Premium</label>
                 <input type="text" name="total_premium" class="form-control" >
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">VAT %</label>
                 <input type="text" name="vat" class="form-control" >

                 <input type="hidden" name="id" id="quot_id" value="">

               </div>
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Insurer Charges</label>
                 <input type="text" name="insurer_charge" class="form-control" >
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
               <div class="row">
                 <div class="col-md-3">
                   <div class="form-group">
                     <label for="">Policy Holders Fund</label>
                     <input type="text" name="policy_holder_fund" class="form-control" >
                   </div>
                 </div>
                 <div class="col-md-3">
                   <div class="form-group">
                     <label for="">Training/Insurance Levy</label>
                     <input type="text" name="insurance_levy" class="form-control" >
                   </div>
                 </div>
                 <div class="col-md-3">
                   <div class="form-group">
                     <label for="">Stamp Duty</label>
                     <input type="text" name="stamp_duty" class="form-control" >
                   </div>
                 </div>
                 <div class="col-md-3">
                   <div class="form-group">
                     <label for="">Withhold Tax</label>
                     <input type="text" name="withhold_tax" class="form-control" >
                   </div>
                 </div>
               </div>
             </div>
             <div class="col-md-6">
               <div class="row">
                 <div class="col-md-6">
                   <div class="form-group">
                     <label for="">VAT Amount</label>
                     <input type="text" name="vat_amount" class="form-control" >
                   </div>
                 </div>
                 <div class="col-md-6">
                   <div class="form-group">
                     <label for="">Total Premium</label>
                     <input type="text" name="tax_total_premium" class="form-control" >
                   </div>
                 </div>
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Business by</label>
                 <textarea name=" business_by" rows="2" class="form-control"></textarea>
               </div>
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Administration Charges</label>
                 <input type="text" name="administrative_charges" class="form-control" >
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-9">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Total Receivable</label>
                 <input type="text" name="total_receivable" class="form-control" >
               </div>
             </div>
           </div>
           <hr/>
           <div class="row">  
             <div class="col-md-12">
               <div class="form-group">
                 <label for="">Additional Terms/Endorsement Details<span class="text-danger">*</span></label>
                 <textarea  class="summernote-textarea" name="score_of_cover" readonly="true" required=""></textarea>
               </div>
             </div>
           </div>
           <hr/>
           <div class="card-footer float-right">
             <button type="submit" class="btn btn-primary">Save</button>
           </div>
         </div>
       </div>
     </div>

   </div>
 </div>
</form>
</section>
</div>


<?php } } } } ?>

<?php if(!empty($type)) { if($type == 'model') {?>
      <div class="content-wrapper">
  <section class="content">
    <div class="container-fluide" style="padding:10px;">
      <h5>Endorsement</h5>
      <div class="row">
        <div class="card width-full">
          <div class="card-body">
            <div class="row">
              <!-- <div class="col-md-2 d-flex">
                <form class=""   action="<?= base_url('Endorsement/life_endorsement_search') ?>" method="post">
                  <div class="form-group">
                    <label>Risk Note #</label>
                    <input type="text" name="risknote_no" value="<?= isset($postdata['risknote_no'])?$postdata['risknote_no']:'' ?>" class="form-control" style="" >
                  </div>
                  <button type="submit" style="height:max-content;margin:auto;" class="btn btn-info" >Fetch</button>
                </form>
              </div> -->
              <?php if(!empty($quotation)) { foreach($quotation as $qs) { ?>
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Insurance type</label>
                    <select class="form-control" name="insurance_type" disabled="">
                      <?php if(!empty($insuranceType)){ ?>
                        <option value="<?php echo $insuranceType['name'];?>"><?php echo $insuranceType['name'];?></option>
                        <?php }?></select>
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label>Old Premium</label>
                        <input type="text" name="old_premium" class="form-control" disabled="">
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <label>Period From</label>
                        <input type="date" name="period_from" class="form-control" value="<?php echo $qs['date_from'];?>" disabled="">
                      </div>
                    </div>

                    <div class="col-md-2">
                      <div class="form-group">
                        <label>To</label>
                        <input type="date" name="to" class="form-control" value="<?php echo $qs['date_to'];?>" disabled="">
                      </div>
                    </div>
                  </div></div>
                </div>
              </div>
            </div>

            <form action="<?php echo base_url('Endorsement/edit_data')?>" method="post">
              <div class="row">
                <div class="card width-full">
                 <div class="card-body">
                   <div class="row">
                     <div class="col-md-4">
                       <div class="form-group">
                         <label>Client Name</label>

                         <input type="text" class="form-control" name="client_name" readonly value="<?php echo $qs['client_name'];?>" >
                       </div>

                       <div class="form-group">
                         <label>Insured Name :</label>
                         <input type="text" class="form-control" name="insured_name" readonly value="<?php echo $qs['insured_name'];?>" >
                       </div>
                     </div>
                     <div class="col-md-4">
                       <div class="row">
                         <div class="form-group width-full">
                           <label>Insurer</label>
                           <select name="insurance_companyname" id="company_name" class="form-control" disabled="">
                            <option value="<?php echo $qs['insurance_company'];?>"><?php echo $qs['insurance_company'];?></option>
                          </select>

                        </div>
                      </div>
                      <div class="form-group">
                       <label>Address</label>
                       <textarea name="address" class="form-control" rows="2" disabled=""><?php echo $qs['address'];?></textarea>
                     </div>
                   </div>
                   <div class="col-md-4">
                     <div class="row">
                       <div class="col-md-6">
                         <div class="form-group">
                           <label>Currency</label>
                           <input type="text" class="form-control" name="currency"  readonly <?php echo $qs['ccy'];?>>
                         </div>
                       </div>
                       <div class="col-md-6">
                         <div class="form-group">
                           <label>Branch</label>
                           <input type="text" name="branch_name"  class="form-control" value="<?php echo $qs['branch_name'];?>" disabled="">
                         </div>
                       </div>
                     </div>
                     <div class="row">
                       <div class="col-sm-5">
                         <div class="form-group">
                           <label>Period From</label>
                           <input type="date" name="date_from" class="form-control" value="<?php echo $qs['date_from'];?>" disabled="">
                         </div>
                       </div>
                       <div class="col-sm-5">
                         <div class="form-group">
                           <label>To</label>
                           <input type="date" name="date_to" class="form-control" value="<?php echo $qs['date_to'];?>" disabled="">
                         </div>
                       </div>
                       <div class="col-sm-2">
                         <div class="form-group">
                           <label>Days</label>
                           <input type="text" name="days_count" class="form-control"  value="<?php echo $qs['days_count'];?>" disabled="">
                         </div>
                       </div>
                     </div>
                   </div>
                 </div>
                 <div class="row">
                   <div class="col-md-6">
                     <div class="form-group">
                       <label>Covering Details</label>
                       <textarea name="covering_details" class="form-control" rows="2" disabled=""><?php echo $qs['covering_details'];?></textarea>
                     </div>
                     <div class="form-group">
                       <label>Firstloss payee :</label>
                       <input type="text" name="firstlosspayee" class="form-control" value="<?php echo $qs['first_loss_payee'];?>" disabled="">
                     </div>
                   </div>
                   <div class="col-md-6">
                     <div class="form-group">
                       <label>Description of Risk</label>
                       <textarea name="name" class="form-control" rows="2" disabled=""><?php echo $qs['description_of_risk'];?></textarea>
                     </div>
                   </div>
                 </div>
                 <div class="row mt-12">
                   <div class="col-md-12 bg-white">
                     <div class="card-header bg-primary">
                       <h3 class="card-title">Insert Panel</h3>
                     </div>
                     <div class="insert-panel-data" style="background-color: #ceea93; padding:8px;">
                       <div class="row mt-4">
                         <div class="col-md-3">
                           <div class="form-group">
                             <label for="">Insurance Class</label>
                             <input type="hidden" name="id" id="id">
                             <select name="insurance_class" id="insurance_class" class="form-control text-capitalize" id="insuranceclass" disabled="">
                                <option value="">standard Rate</option>
                             </select>
                             <input type="hidden" name="quot_id" id="quot_id" value="<?php echo $qs['id'];?>" >
                           </div>
                           <div class="form-group">
                             <label for="">Description<span class="text-danger">*</span></label>
                             <textarea  class="form-control" name="description" id="description" disabled=""><?php echo $liferecord['description'];?></textarea>
                           </div>
                         </div>
                         <div class="col-md-2">
                           <div class="form-group">
                             <label for="">Date of birth</label>
                             <input type="date" class="form-control" name="date_of_birth" id="date_of_birth" onchange="myFunction()" value="<?php echo $liferecord['dob'];?>" disabled="">
                           </div>
                           <div class="form-group">
                             <label for="">age</label>
                             <input type="text" name="age" id="age" class="form-control" value="<?php echo $liferecord['age'];?>" disabled="">
                           </div>
                           <div class="form-group">
                             <label for="">Member Add Date </label>
                             <input type="date" name="member_date" id="member_date" class="form-control" value="<?php echo $liferecord['member_add_date'];?>" disabled="" >
                           </div>
                           <div class="form-group">
                             <label for="">Branch Name </label>
                             <input type="text" name="branch_name" id="branch_name" class="form-control" value="<?php echo $liferecord['branch_name'];?>" disabled="">
                           </div>
                           <div class="form-group">
                             <label for="">Monthly Fee</label>
                             <input type="text" name="monthly_fee" id="monthly_fee" class="form-control" value="<?php echo $liferecord['monthly_fees'];?>" disabled="" >
                           </div>
                         </div>
                         <div class="col-md-2">
                           <div class="form-group">
                             <label for="">ID Type</label>
                             <input type="text" class="form-control" id="id_type" name="id_type" value="<?php echo $liferecord['id_type'];?>"  disabled="">
                           </div>
                           <div class="form-group">
                             <label for="">ID Number</label>
                             <input type="number" class="form-control" name="id_number" id="id_number" value="<?php echo $liferecord['id_number'];?>" disabled="">
                           </div>
                           <div class="form-group">
                             <label for="">Primary Member Id</label>
                             <select name="primary_member_id" id="primary_member_id" class="form-control" value="<?php echo $liferecord['primary_member_id'];?>" disabled="">
                               <option value="1">1</option>
                             </select>
                           </div>
                           <div class="form-group">
                             <label for="">Account number</label>
                             <input type="number" class="form-control" name="account_number" id="account_number" value="<?php echo $liferecord['account_number'];?>" disabled="">
                           </div>
                           <div class="form-group">
                             <label for="">Transaction date</label>
                             <input type="date" class="form-control" name="transaction_date" id="transaction_date" value="<?php echo $liferecord['transaction_date'];?>" disabled="">
                           </div>

                         </div>
                         <div class="col-md-2">
                           <div class="form-group">
                             <label for="">Relationship</label>
                             <select name="relationship" id="relationship" tabindex="22" class="form-control" disabled="">
                              <option value="">Please Select</option>
                              <?php foreach($relationship as $rs){ ?>
                                    <option value="<?php echo $rs['name'];?>" <?php if($rs['name']==$liferecord['relationship']){ echo "selected";} ?>><?php echo $rs['name'];?></option>
                              <?php } ?>

                            </select>
                          </div>
                          <div class="form-group">
                           <label for="">Gender</label>
                           <select name="gender" class="form-control" id="gender" disabled="">
                              <option disabled="">Please select</option>
                              <option value="male" <?php if($liferecord['gender']=='male') { echo "selected";}?>>male</option>
                              <option value="female" <?php if($liferecord['gender']=='female') { echo "selected";}?>>female</option></select>
                         </div>
                         <div class="form-group">
                           <label for="">Pre Existing condition</label>
                           <textarea name="pre_existing_condition" id="pre_existing_condition" class="form-control" disabled=""><?php echo $liferecord['pre_existing_condition'];?></textarea>
                         </div>
                       </div>
                       <div class="col-md-2">
                         <div class="form-group">
                           <label for="">Sum_Assured</label>
                           <input type="text" name="sum_insured" class="form-control" id="sum_insured" value="<?php echo $liferecord['sum_assured'];?>" disabled="">
                         </div>
                         <div class="form-group">
                           <label for=""><span class="bold">Total Premium</span><span style="color: Red"> *</span></label>
                           <input type="text" name="total_premium" class="form-control" id="total_premium" value="<?php echo $liferecord['total_premium'];?>" disabled="">
                           <input type="hidden" id="id" name="id">
                         </div>
                         <div class="form-group">
                           <input type="button" class="btn btn-primary Insert"  id="insertid" value="Insert">
                           <input type="button" class="btn btn-success Insert"  id="updateid" value="Update">
                         </div>
                       </div>
                     </div>
                   </div>
                   <div class="row">
                     <div class="col-lg-3">
                       <label>Upload Excel File</label>
                       <input type="text" name="Upload_file" class="form-control" disabled="">
                     </div>
                     <div class="col-lg-3">
                       <label></label>
                       <input type="file" name="Upload_file" class="form-control" disabled="">
                     </div>
                     <div class="col-lg-2">
                       <label></label><br>
                       <input type="button" name="" value="Process File" class="btn btn-primary" disabled="">
                     </div>
                     <div class="col-lg-5">
                       <label></label><br>
                       <a href="#" id="MainContent_btnDwnldTmplt" target="_blank" title="Click here to download Excel Template">Click here to download
                       Excel Template</a>
                     </div>



                   </div>
                   <div class="row">
                    <div class="col-lg-3">
                     <p>Search Criteria</p>
                   </div>
                 </div>
                 <div class="row">

                  <div class="col-md-2" style="border-left: 1px solid black;border-top:1px solid black;border-bottom: 1px solid black; ">
                   <div class="form-group">
                     <label for="">Id</label>
                     <input type="text" name="id" class="form-control" >
                   </div>
                 </div>
                 <div class="col-md-2"  style="border-top:1px solid black;border-bottom: 1px solid black; ">
                   <div class="form-group">
                     <label for="">description</label>
                     <input type="text" name="description" class="form-control" disabled="" >
                   </div>
                 </div>
                 <div class="col-md-2" style="border-top:1px solid black;border-bottom: 1px solid black; ">
                   <div class="form-group">
                     <label for="">Relationship</label>
                     <input type="text" name="insurer_settlement" class="form-control" disabled="" >
                   </div>
                 </div>
                 <div class="col-md-6" style="border-top:1px solid black;border-bottom: 1px solid black;border-right: 1px solid black;">
                   <div class="form-group"><br>
                     <input type="button" name="Fetch" value="Fetch" class="btn btn-primary">
                   </div>
                 </div>

               </div>
               <table class="table">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">description</th>
                    <th scope="col">DOB</th>
                    <th scope="col">Age</th>
                    <th scope="col">Id type/Id number</th>
                    <th scope="col">Relationship</th>
                    <th scope="col">Sum Assured</th>
                    <th scope="col">Premium</th>
                    <th scope="col">cancel Amount</th>
                    <th scope="col">Add date</th>
                    <th scope="col">Remove date</th>
                    <th scope="col">status</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody id="insertpaneldata">
                </tbody>
              </table>
              <div class="row">
               <div class="col-md-3">
                 <div class="form-group">
                   <label for="">Commission Rate %</label>
                   <input type="text" name="commission-rate" class="form-control" disabled="">
                 </div>
               </div>
               <div class="col-md-3">
                 <div class="form-group">
                   <label for="">Broker Settlement</label>
                   <input type="text" name="broker_settlement" class="form-control" disabled="">
                 </div>
               </div>
               <div class="col-md-3">
                 <div class="form-group">
                   <label for="">Insurer Settlement</label>
                   <input type="text" name="insurer_settlement" class="form-control" disabled="">
                 </div>
               </div>
               <div class="col-md-3">
                 <div class="form-group">
                   <label for="">Added Premium</label>
                   <input type="text" name="added_premium" class="form-control" disabled="">
                 </div>
               </div>
             </div>
             <div class="row">
               <div class="col-md-6">
               </div>
               <div class="col-md-3">
                <div class="form-check">
                 <input class="form-check-input" type="checkbox" value="">
                 <label class="form-check-label"><b>Non-Financial Endorsement</b></label>
               </div>
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Cancelled Premium</label>
                 <input type="text" name="cancelled_premium" class="form-control" disabled="">
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
             </div>
             <div class="col-md-3">

             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Total Premium :</label>
                 <input type="text" name="total_premium" class="form-control" disabled="">
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
             </div>
             <div class="col-md-3">

             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Other fee</label>
                 <input type="text" name="other_fee" class="form-control" disabled="">
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-9">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Insurer Charges</label>
                 <input type="text" name="insurer_charge" class="form-control" disabled="">
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-9">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Total Premium</label>
                 <input type="text" name="total_premium" class="form-control"  disabled="">
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">VAT %</label>
                 <input type="text" name="vat" class="form-control"  disabled="">

                 <input type="hidden" name="id" id="quot_id" value="" >

               </div>
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Insurer Charges</label>
                 <input type="text" name="insurer_charge" class="form-control" disabled="">
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
               <div class="row">
                 <div class="col-md-3">
                   <div class="form-group">
                     <label for="">Policy Holders Fund</label>
                     <input type="text" name="policy_holder_fund" class="form-control" disabled="">
                   </div>
                 </div>
                 <div class="col-md-3">
                   <div class="form-group">
                     <label for="">Training/Insurance Levy</label>
                     <input type="text" name="insurance_levy" class="form-control" disabled="">
                   </div>
                 </div>
                 <div class="col-md-3">
                   <div class="form-group">
                     <label for="">Stamp Duty</label>
                     <input type="text" name="stamp_duty" class="form-control" disabled="">
                   </div>
                 </div>
                 <div class="col-md-3">
                   <div class="form-group">
                     <label for="">Withhold Tax</label>
                     <input type="text" name="withhold_tax" class="form-control" disabled="">
                   </div>
                 </div>
               </div>
             </div>
             <div class="col-md-6">
               <div class="row">
                 <div class="col-md-6">
                   <div class="form-group">
                     <label for="">VAT Amount</label>
                     <input type="text" name="vat_amount" class="form-control"  disabled="">
                   </div>
                 </div>
                 <div class="col-md-6">
                   <div class="form-group">
                     <label for="">Total Premium</label>
                     <input type="text" name="tax_total_premium" class="form-control"  disabled="">
                   </div>
                 </div>
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-6">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Business by</label>
                 <textarea name=" business_by" rows="2" class="form-control" disabled=""></textarea>
               </div>
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Administration Charges</label>
                 <input type="text" name="administrative_charges" class="form-control" disabled="" >
               </div>
             </div>
           </div>
           <div class="row">
             <div class="col-md-9">
             </div>
             <div class="col-md-3">
               <div class="form-group">
                 <label for="">Total Receivable</label>
                 <input type="text" name="total_receivable" class="form-control" disabled="" >
               </div>
             </div>
           </div>
           <hr/>
           <div class="row">  
             <div class="col-md-12">
               <div class="form-group">
                 <label for="">Additional Terms/Endorsement Details<span class="text-danger">*</span></label>
                 <textarea  class="summernote-textarea" name="score_of_cover" readonly="true" required="" ></textarea>
               </div>
             </div>
           </div>
           <hr/>
           <div class="card-footer float-right">
             <button type="submit" class="btn btn-primary">Save</button>
           </div>
         </div>
       </div>
     </div>

   </div>
 </div>
</form>
</section>
</div>

      


<?php }}}}?>

<script type="text/javascript">
 
  $(document).ready(function(){
     $("#updateid").hide(); 
    $("#insertid").click(function() {
     
      var quot_id=$("#quot_id").val();
      var insurance_class=$("#insurance_class").val();
      var description=$("#description").val();
      var date_of_birth=$("#date_of_birth").val();
      var age=$("#age").val();
      var member_add_date=$("#member_date").val();
      var branch_name=$("#member_date").val();
      var monthly_fee=$("#monthly_fee").val();
      var id_type=$("#id_type").val();
      var id_number=$("#id_number").val();
      var primary_member_id=$("#primary_member_id").val();
      var account_number=$("#account_number").val();
      var transaction_date=$("#transaction_date").val();
      var relationship=$("#relationship").val();
      var gender=$("#gender").val();
      var pre_existing_condition=$("#pre_existing_condition").val();
      var sum_insured=$("#sum_insured").val();
      var total_premium=$("#total_premium").val();

      $.ajax({
        type:"post",
        datatype:"json",
        url:"<?=site_url('Endorsement/life_endorsement_insertpanel')?>",
        data:{quo_id:quot_id,dob:date_of_birth,age:age,member_add_date:member_add_date,branch_name:branch_name,monthly_fees:monthly_fee,id_type:id_type,id_number:id_number,primary_member_id:primary_member_id,account_number:account_number,transaction_date:transaction_date,relationship:relationship,gender:gender,pre_existing_condition:pre_existing_condition,sum_assured:sum_insured,total_premium:total_premium},
        success:function(data)
        {
          getInsertpaneltb2(data);
        }
      });
    });
  });
  function getInsertpaneltb2(id) {
    $("#description").val('');
    $("#date_of_birth").val('');
    $("#age").val('');
    $("#member_date").val('');
    $("#monthly_fee").val('');
    $("#id_type").val('');
    $("#id_number").val('');
    $("#primary_member_id").val('');
    $("#account_number").val('');
    $("#transaction_date").val('');
    $("#relationship").val('');
    $("#gender").val('');
    $("#pre_existing_condition").val('');
    $("#sum_insured").val('');
    $("#total_premium").val('');
    $.ajax({
      type:"post",
      datatype:"json",
      url:"<?=site_url('Endorsement/get_life_insertpaneltb2')?>",
      data:{id:id},
      success:function(data)
      {
        $('#insertpaneldata').html(data);
        console.log(data);
      }
    });
  } 
  function list_edit(id) {
        $.ajax({
      type:"post",
      datatype:"json",
      url:"<?=site_url('Endorsement/get_life_insertpaneldata1')?>",
      data:{id:id},
      success:function(data)
      {
        var obj=JSON.parse(data);
        $("#updateid").show();
        $("#id").val(obj.id);
        $("#description").val(obj.description);
        $("#date_of_birth").val(obj.dob);
        $("#age").val(obj.age);
        $("#member_date").val(obj.member_add_date);
        $("#monthly_fee").val(obj.monthly_fees);
        $("#id_type").val(obj.id_type);
        $("#id_number").val(obj.id_number);
        $("#primary_member_id").val(obj.primary_member_id);
        $("#account_number").val(obj.account_number);
        $("#transaction_date").val(obj.transaction_date);
        $("#relationship").val(obj.relationship);
        $("#gender").val(obj.gender);
        $("#pre_existing_condition").val(obj.pre_existing_condition);
        $("#sum_insured").val(obj.sum_assured);
        $("#total_premium").val(obj.total_premium);
        $("#insertid").hide();
      
      }
    });
    }
$('#updateid').click(function(){
   $("#updateid").hide(); 
      var quot_id=$("#quot_id").val();
      var id=$("#id").val();
      var insurance_class=$("#insurance_class").val();
      var description=$("#description").val();
      var date_of_birth=$("#date_of_birth").val();
      var age=$("#age").val();
      var member_add_date=$("#member_date").val();
      var branch_name=$("#member_date").val();
      var monthly_fee=$("#monthly_fee").val();
      var id_type=$("#id_type").val();
      var id_number=$("#id_number").val();
      var primary_member_id=$("#primary_member_id").val();
      var account_number=$("#account_number").val();
      var transaction_date=$("#transaction_date").val();
      var relationship=$("#relationship").val();
      var gender=$("#gender").val();
      var pre_existing_condition=$("#pre_existing_condition").val();
      var sum_insured=$("#sum_insured").val();
      var total_premium=$("#total_premium").val();
       $("#insertid").show();

      $.ajax({
        type:"post",
        datatype:"json",
        url:"<?=site_url('Endorsement/edit_life_insurance_class_insert')?>",
        data:{id:id,quo_id:quot_id,dob:date_of_birth,age:age,member_add_date:member_add_date,branch_name:branch_name,monthly_fees:monthly_fee,id_type:id_type,id_number:id_number,primary_member_id:primary_member_id,account_number:account_number,transaction_date:transaction_date,relationship:relationship,gender:gender,pre_existing_condition:pre_existing_condition,sum_assured:sum_insured,total_premium:total_premium},
        success:function(data)
        {
          getInsertpaneltb2(data);
        }
      });
    });
  
</script>