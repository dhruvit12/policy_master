<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Client</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Client</a></li>
              <li class="breadcrumb-item active">Edit</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" method="post" action="<?php echo base_url('Client/update_client')?>">
                <!-- Row 2 Start here -->
                <div class="row">
                  <div class="col-md-6">
                    <div class="card-body">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Title</label>
                        <input type="hidden" name="id" value="<?php echo $list['id'];?>">
                        <select class="form-control" name="title">
                          <option selected="true" disabled="true"> Select Title</option>
                          <option value="mr" <?php if($list['title']=='mr'){ echo "selected"; } ?>>Mr</option>
                          <option value="mrs" <?php if($list['title']=='mrs'){ echo "selected"; } ?>>Mrs</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="">Client Name</label>
                        <input type="text" class="form-control" id="client-name" placeholder="Enter Client Name" name="client-name" value="<?php echo $list['client_name'];?>">
                      </div>
                      <div class="form-group">
                        <label for="">Account Number</label>
                        <input type="text" class="form-control" id="account-number" placeholder="Account No"  name="account-number" value="<?php echo $list['account_number'];?>">
                      </div>
                       <font color="red">  </font>
                      <div class="form-group">
                        <label for="inputClient">Client Type</label>
                        <select class="form-control custom-select text-capitalize" name="client-type">
                          <option selected disabled>Select one</option>
                         
                            <option value="Individual" <?php if($list['client_type']=='Individual'){ echo "selected"; }?>>Individual</option>
                            <option value="Staff" <?php if($list['client_type']=='Staff'){ echo "selected"; }?>>Staff</option>
                            <option value="Commercial Banking" <?php if($list['client_type']=='Commercial Banking'){ echo "selected"; }?>>Commercial Banking</option>
                             <option value="Other" <?php if($list['client_type']=='Other'){ echo "selected"; }?>>Other</option>
                 
                        </select>
                      </div>
                    </div>
                  </div>
                  <span class="mycontent-left"></span>
                  <div class="col-md-6">
                    <div class="card-body">
                      <div class="form-group">
                        <label for="inputEntity">Entity</label>
                        <select class="form-control custom-select" name="entity">
                          <option selected disabled>Select one</option>
                          <option value="Client" <?php if($list['entity']=='client'){ echo "Selected";}?>> Client</option>
                          <option value="Supplier" <?php if($list['entity']=='cupplier'){ echo "Selected";}?> >Supplier</option>
                          <option value="both"  <?php if($list['entity']=='both'){ echo "Selected";}?>  >Both</option>
                        </select>
                      </div>
                      <div class="form-group">
                          <label for="">Occupation<span class="text-danger">*</span></label>
                          <select class="form-control text-capitalize" id="role" name="occupation" required="true">
                            
                              <option value="Accountant" <?php if($list['occupation']=='Accountant'){ echo "selected"; }?>>Accountant</option>
                              <option value="Administrative Officer" <?php if($list['occupation']=='Administrative Officer'){ echo "selected"; }?>>Administrative Officer</option>
                              <option value="Agricultural" <?php if($list['occupation']=='Agricultural'){ echo "selected"; }?>>Agricultural</option>
                              <option value="Librarian" <?php if($list['occupation']=='Librarian'){ echo "selected"; }?>>Librarian</option>
                              <option value="Teacher" <?php if($list['occupation']=='Teacher'){ echo "selected"; }?>>Teacher</option>
                          </select>
                        </div>
                       <div class="form-group">
                          <label for="inputGender">Gender<span class="text-danger">*</span></label>
                          <select class="form-control custom-select" name="gender" required="true">
                            <option selected disabled>Select one</option>
                            <option value="male" <?php if($list['gender']=='male'){ echo "selected"; }?>>Male</option>
                            <option value="female" <?php if($list['gender']=='female'){ echo "selected"; }?>>Female</option>
                            <option value="other" <?php if($list['gender']=='other'){ echo "selected"; }?>>Other</option>
                          </select>
                        </div>
                    </div>
                  </div>
                </div>
                <!-- Row 2 end here -->
                <hr/>
                <!-- Row 3 Start here -->
                <div class="row ">
                  <div class="col-md-6">
                    <div class="card-body">
                      <div class="form-group">
                        <label for="inputId">ID Type</label>
                        <select class="form-control custom-select" name="id-type" required="true">
                          <option selected disabled>Select one</option>
                  
                          <option value="License" <?php if($list['idproof_type']=='License'){ echo "selected"; }?>>License</option>
                          <option value="Voter Id" <?php if($list['idproof_type']=='Voter Id'){ echo "selected"; }?>>Voter Id</option>
                          <option value="National ID" <?php if($list['idproof_type']=='National ID'){ echo "selected"; }?>>National ID</option>
                          <option value="Staff ID" <?php if($list['idproof_type']=='Staff ID'){ echo "selected"; }?>>Staff ID</option>
                        
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="">Id Proof Number</label>
                        <input type="text" class="form-control" id="id-number" placeholder="Enter ID Number" name="id-number" value="<?php echo $list['id_number'];?>" required="true"/>
                      </div>
                      <div class="form-group">
                        <label for="">Date of Birth</label>
                        <input type="date" class="form-control" id="dob" name="dob" value="<?php echo $list['dob'];?>" required="true"/>
                      </div>
                      <div class="form-group">
                        <label for="inputnin">NIN</label>
                        <input type="text" class="form-control" id="nin" name="nin" value="<?php echo $list['nin'];?>" required="true"/>
                      </div>
                       <?php $datas=explode(',',$list['email']);?>
                      <div class="form-group">
                        <label for="">Email Address 1</label>
                        <input type="email" class="form-control" id="email1" placeholder="Enter Email 1" name="email1" value="<?php echo $datas[0];?>" required="true"/>
                      </div>
                      <div class="form-group">
                        <label for="">Email Address 2</label>
                        <input type="email" class="form-control" id="email2" placeholder="Enter Email 2" name="email2" value="<?php echo $datas[1];?>"/>
                      </div>
                      <div class="form-group">
                        <label for="">Email Address 2</label>
                        <input type="email" class="form-control" id="email3" placeholder="Enter Email 2" name="email3" value="<?php echo $datas[2];?>"/>
                      </div>
                    </div>
                  </div>
                  <span class="mycontent-left"></span>
                  <div class="col-md-6">
                    <div class="card-body">
                      <div class="form-group">
                        <?php $datak=explode(',',$list['mobile_number']);?>
                        <label for="">Mobile Number 1</label>
                        <input type="text" class="form-control" id="mobile_number1" maxlength="10" placeholder="Mobile No" name="mobile_number1" value="<?php echo $datak[0];?>" required="true"/>
                      </div>
                      <div class="form-group">
                        <label for="">Mobile Number 2</label>
                        <input type="text" class="form-control" id="mobile_number2" maxlength="10" placeholder="Mobile No" name="mobile_number2" value="<?php echo $datak[1];?>">
                      </div>
                      <div class="form-group">
                        <label for="">Mobile Number 3</label>
                        <input type="text" class="form-control" id="mobile_number3" maxlength="10" placeholder="Mobile No" name="mobile_number3" value="<?php echo $datak[2];?>">
                      </div>
                      <?php $data1=explode(',',$list['tel_no']);?>
                      <div class="form-group">
                        <label for="">Tel No 1</label>
                        <input type="text" class="form-control"  maxlength="10" placeholder="Mobile No" name="tel-no1" value="<?php echo $data1[0];?>">
                      </div>
                      <div class="form-group">
                        <label for="">Tel No 2</label>
                        <input type="text" class="form-control" placeholder="Enter Tel No" name="tel-no2" maxlength="10" value="<?php echo $data1[1];?>">
                      </div>
                      <div class="form-group">
                        <label for="">Tel No 3</label>
                        <input type="text" class="form-control"  placeholder="Enter Tel No" name="tel-no3" maxlength="10" value="<?php echo $data1[2];?>">
                      </div>
                      <div class="form-group">
                        <label for="address">Address</label>
                        <textarea id="address" class="form-control" rows="4" name="address" required="true"><?php echo $list['address'];?></textarea>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Row 3 end here -->
                <hr/>
                <!-- Row 4 Start here -->
                <div class="row">
                  <div class="col-md-6">
                    <div class="card-body">
                      <div class="form-group">
                        <label for="inputId">Business Type</label>
                        <select class="form-control custom-select" name="business-type" >
                          <option selected disabled>Select one</option>
                         
                          <option value="Agribusiness" <?php if($list['business_type']=='Agribusiness'){ echo "selected"; }?>>Agribusiness</option> 
                          <option value="Civil engineering" <?php if($list['business_type']=='Civil engineering'){ echo "selected"; }?>>Civil engineering</option>
                          <option value="Food, Grocery, Beer Wine" <?php if($list['business_type']=='Food, Grocery, Beer Wine'){ echo "selected"; }?>>Food, Grocery, Beer Wine</option>
                          <option value="Information Technology" <?php if($list['business_type']=='Information Technology'){ echo "selected"; }?>>Information Technology</option>
                          <option value="Others" <?php if($list['business_type']=='Others'){ echo "selected"; }?>>Others</option>
                        
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="">Contact Person</label>
                        <input type="text" class="form-control" id="contact-person" placeholder="Enter Name" name="contact-person" value="<?php echo $list['contact_person'];?>">
                      </div>
                      <div class="form-group">
                        <label for="vrn">VRN</label>
                        <input type="text" class="form-control" id="vrn" name="vrn" value="<?php echo $list['vrn'];?>">
                      </div>
                      <div class="form-group">
                        <label for="tin">TIN</label>
                        <input type="text" class="form-control" id="tin" name="tin" value="<?php echo $list['tin'];?>">
                      </div>
                    </div>
                  </div>
                  <span class="mycontent-left"></span>
                  <div class="col-md-6">
                    <div class="card-body">
                      <!-- checkbox -->
                      <div class="form-group">
                        <label for="checkboxPrimary1">Preferred System Notification</label>
                        <br/>
                       
                        <input type="checkbox" id="sms" name="notice"  value="sms" <?php if($list['preferred_system_notice']=='sms'){ echo 'checked';}?> />
                        <label for="checkboxPrimary1">
                          SMS
                        </label>
                        <input type="checkbox" id="email" name="notice" value="email" <?php if($list['preferred_system_notice']=='email'){ echo 'checked';}?> >
                        <label for="checkboxPrimary1">
                          EMAIL
                        </label>
                      </div>
                      <input type="hidden" id="notice" name="noticetype">
                      <div class="form-group">
                        <label for="">Appointment Date</label>
                        <input type="date" class="form-control" id="appointment-date" name="appointment-date" value="<?php echo $list['appointment_date'];?>">
                      </div>
                      <div class="form-group">
                        <label for="">Mandate Expiry</label>
                        <input type="date" class="form-control" id="mandate-expiry" name="mandate-expiry" value="<?php echo $list['mandate_expiry'];?>">
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Row 4 end here -->
                <!-- /.card-body -->
                <hr/>
                <div class="card-footer float-right">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
  </div>
<script type="text/javascript">
//Check box vlaue
  $(document).ready(function(){

    $('input[type="checkbox"]').change(function()
    {
       var checkedValue=$('input:checkbox:checked').map(function()
        {
            return this.value;
        }).get();            
        $("#notice").val(checkedValue);           
    })    
 });
            
</script>