<?php
$validation =  \Config\Services::validation();

?>
<?php
    $session = session();
 ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <span>Change Password</span>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Auth</a></li>
              <li class="breadcrumb-item active">Change Password</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="col-md-12">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Change Password</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <div class="spacer-10"></div>
              <?php if ($msg=$session->getFlashdata('error')): ?>
              <div class="alert alert-<?=$session->getFlashdata('error_class')?> alert-dismissible fade show" role="alert">
                <strong><?= $msg ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <?php  endif; ?>
              <form class="form-horizontal" action="<?=base_url('auth/changePassword')?>" method="post">
                <div class="card-body">
                  <div class="">
                  <div class="text-center text-danger mb-3"></div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-form-label">Current Password<span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="current-password" name="current_password" placeholder="Current Password" required="true">
                    <?php if ($validation->hasError('current-password')){ ?> <font color="red"> <?php echo $validation->getError('current-password');?> </font><?php } ?>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-form-label">New Password<span class="text-danger">*</span></label>
                    <input type="password" class="form-control" minlength="4" maxlength="15" id="new-password" name="new_password" placeholder="New Password">
                    <?php if ($validation->hasError('new-password')){ ?> <font color="red"> <?php echo $validation->getError('new-password');?> </font><?php } ?>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-form-label">Confirm Password<span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="confirm-password" minlength="4" maxlength="15" name="confirm_password" placeholder="Confirm Password">
                    <?php if ($validation->hasError('confirm-password')){ ?> <font color="red"> <?php echo $validation->getError('confirm-password');?> </font><?php } ?>
                  </div>

                </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary float-right">Update</button>
                </div>
                <!-- /.card-footer -->
              </form>
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
  </div>
