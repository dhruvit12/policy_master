<?php
  echo view('templete/header');
  echo view('templete/navbar');
  echo view($page);
  echo view('templete/footer');
 ?>
