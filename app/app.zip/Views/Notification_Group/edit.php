 <div class="content-wrapper"><div class="container">
            <form action="<?php echo base_url('Notification_Group/edit_success')?>" method="post">
            <input type="hidden" id="dp-quot-id" name="id" value="<?php  echo $edit['id'];?>">
            <input type="hidden" id="dp-debitnoteno" name="debitnoteno" value="">
            <input type="hidden" id="dp-client-id" name="client_id" value="">
            <input type="hidden" id="dp-currency-id" name="currency_id" value="">
            <input type="hidden" id="dp-current-balance" name="current_balance" value="">
            <input type="hidden" id="dp-branch-id" name="branch_id" value="">
              <div class="row">
              <div class="col-md-12 ">
                <div class="form-group">
                  <label>Group Name:</label>
                  <input type="text"  class="form-control" name="Group_Name" value="<?php  echo $edit['Group_Name'];?>"></div>
              </div>
            </div>
              <div class="row">
              <div class="col-md-12">
                 <div class="form-group">
                  <label>Users:</label>
                  <input type="text"  class="form-control" name="Users" value="<?php  echo $edit['Users'];?>"></div>
                         </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="exampleFormControlSelect1">External Emails:</label>
                   <input type="text" name="External_Emails" value="<?php  echo $edit['External_Emails'];?>"  class="form-control" >
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label for="exampleFormControlSelect1">External Mobiles :</label>
                    <input type="text" name="External_Mobiles" value="<?php  echo $edit['External_Mobiles'];?>"  class="form-control" >
                  </div>
              </div>
            </div>
            <div class="modal-footer">
            <input type="submit" name="" class="btn btn-primary" value="Update">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Exit</button>
          </div>
        </form>
      </div>
 