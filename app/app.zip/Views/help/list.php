<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <span>SUPPORT CONTACTS </span>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <div class="row">
    <div class="col-sm-4">
      <center>
        <img src="<?php echo base_url()?>/public/assets/helpimage/wt.png" height="100px" width="100px" style="border-radius: 20px;"><br>
        <h4 class="text-primary">1. +1234567892 (demo account)</h4>
        <br>
        <h4 class="text-primary">2. +1234567892 (demo account)</h4>
        <br>
        <h4 class="text-primary">3. +1234567892 (demo account)</h4>
        <br>
      </center>
    </div>
    <div class="col-sm-4">
      <center><img src="<?php echo base_url()?>/public/assets/helpimage/skype.png" height="100px" width="100px" style="border-radius: 20px;">
        <br>
        <h4 class="text-primary">1. policymaster1</h4>
        <br>
        <h4 class="text-primary">2. policymaster2</h4>
        <br>
        <br><br>
      </center>
    </div>
    <div class="col-sm-4">
      <center><img src="<?php echo base_url()?>/public/assets/helpimage/mail.png" height="100px" width="100px" style="border-radius: 20px;">
        <h4 class="text-primary">Policymaster.in</h4>
        <br>
        <p>- For any queries,email us on the above Email id.</p>
        <br>
      </center>
    </div>
  </div>
   <center>
 
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-info  ">
        <div class="panel-heading">For Remote Support</div>
        <div class="panel-body"><h4> Please click on the below link to download Team Viewer:</h4>
          <h3 class="text-primary">Teamviewer/SmartPolicySupport/Download</h3>
        <h4><b>“TeamViewerQS.exe”</b>
         file will be downloaded on your “Downloads” folder. Please copy and paste the downloaded file on your Desktop for future use.)</h4>
      <blockquote>  Please Note:<br>1. After download, provide your Team Viewer Id &amp; Password to the support team to assist you.<br>    2. Once you are done with the assistance, please close the Team Viewer, so that the remote connectivity is disconnected.
                                            </blockquote>
       </div>
    </div>
  </div>
  </center>
  </div>
  