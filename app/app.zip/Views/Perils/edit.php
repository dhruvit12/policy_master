<br><br><br>
  <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">Peris Details</h5>
          
          </div>
          <div class="modal-body">
          	<?php  foreach($list as $data){
          	?>
          		
            <form action="<?= base_url('perils/update') ?>/<?php echo $data['id'];?>" method="post">
            
           
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="exampleFormControlSelect1">Peris ID:</label>
                <input type="text" name="perilsid" class="form-control" value="<?php echo $data['perilsid'];?>"> 
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="exampleFormControlSelect1">Peris Type :</label>
                  <select class="form-control" id="dp-currency" name="perilstype"><option disabled="">Select option</option>
                  <?php foreach($perilstype as $pt){?> <option value="<?php echo $pt['perils_type_name'];?>" <?php if($data['perilstype']==$pt['perils_type_name']){ echo "selected"; } ?>><?php echo $pt['perils_type_name'];?></option><?php } ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">	
                  <label for="exampleFormControlSelect1">Peris Group:</label>
                 <select class="form-control" name="perilsgroup" id="dp-currency" >
                   <option disabled="">Please select</option>
                      <?php foreach($perilsgroup as $pg){?><option value="<?php echo $pg['perils_group'];?>" <?php if($pg['perils_group']==$data['perilsgroup']){ echo "selected";} ?>><?php echo $pg['perils_group'];?></option><?php } ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
                  <div class="card" style="width:100%;">
                    <h6 class="card-header bg-primary" style="height:30px;padding:5px;">Select Insurance Type / Class</h6>
                    <div class="row">
                        <div class="col-md-6">
                           <input type="text"  placeholder="Search Insurance Type / Classs" class="form-control">
                        </div>
                         <div class="col-md-6">
                           <input type="text"  placeholder="Search Insurance Type / Classs" class="form-control">
                        </div>
                      </div>
                      <br>
                       <div class="row">
                        <div class="col-md-6">
                           <select multiple="multiple" id="my-select" name="insurance_class_type[]" class="form-control" >
                               <option></option>
                               <?php $arr=explode(" ",$data['insurance_class_type']);
                                  
                               foreach($insurancetype as $it){?>

                                  <option value="<?php echo $it['insurance_type_name'];?>"
                                   <?php if($it['insurance_type_name']==$arr){ echo "selected";}?>>
                                  	  <?php echo $it['insurance_type_name'];?></option>
                                  	 <?php } ?>
                                  	 <?php foreach($insuranceclass as $ic){?>
                                  	 	<option value="<?php echo $ic['name'];?>" <?php if($ic['name']==$arr) {
                                  	 	       echo "selected";}?>>
                                  	 		<?php echo $ic['name'];?></option>
                                  	 	<?php } ?>
                            </select>
                          </div>
                      </div>
                    
             <script src="<?=base_url('public/assets/js/jquery.multi-select.js');?>"></script>
    <link rel="stylesheet" type="text/css" href="<?=base_url('public/assets/css/multi-select.css')?>">

   <script type="text/javascript">
            $('#my-select').multiSelect()
          </script>
         
                           </div>
         </div>
          <div class="modal-footer">
            <input type="submit" class="btn btn-primary" value="Update">
            <a href="<?php echo base_url('Perils') ?>" class="btn btn-secondary">Exit</a>
          </div>
        </form>
    <?php } ?>
        </div>
      </div>
  </div>
</div>