<?php
/**
 *
 */
class Qrmodel extends CI_Model
{
	
		// return $this->qrcode->printSVG();
  }
}
?>