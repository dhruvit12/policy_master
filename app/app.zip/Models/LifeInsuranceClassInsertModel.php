<?php namespace App\Models;

use CodeIgniter\Model;

class LifeInsuranceClassInsertModel extends Model
{
	protected $table      = 'life_insurance_class_insert';
	protected $primaryKey = 'id';

	// protected $returnType = 'array';

	// this happens first, model removes all other fields from input data
	protected $allowedFields = [
		'id', 'quot_id', 'client_id', 'token', 'insured_name', 'dob', 'age', 'id_type', 'id_number', 'annual_salary',
		'gender', 'sum_assured', 'relationship', 'premium', 'is_added', 'created_at', 'updated_at'
	];

}
