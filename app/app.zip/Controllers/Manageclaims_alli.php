<?php namespace App\Controllers;
use CodeIgniter\Controller;
use Config\Email;
use Config\Services;
use App\Models;

class Manageclaims_alli extends BaseController
{
  public function __construct()
	{

	}
	public function index()
	{
    $session = session();
    if (!isset($_SESSION['userdata'])) {
			return redirect()->to(site_url('auth'));
		}
    $M_manageclaims = new Models\ManageClaimsInsurerModel();
    $manageclaims = $M_manageclaims->where(['is_deleted'=>0])->findAll();
    $ret=array();
    foreach ($manageclaims as $key) {
      $M_quotation = new Models\QuotationModel();
      $M_quotation->select('insurance_quotation.*,insurance_company.insurance_company,clients.client_name');
      $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
      $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
      $quot = $M_quotation->where(['insurance_quotation.is_deleted'=>0,'insurance_quotation.id'=>$key['quot_id']])->first();
   // echo "<pre>";print_r($manageclaims);exit;
      $key['insurance_company']=$quot['insurance_company'];
      $key['client_name']=$quot['client_name'];
      $ret[]=$key;
    }
    $M_insurancecompany = new Models\InsuranceCompanyModel();
    $data['insurancecompanys'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $data['list']=$ret;
    $data['page']='manageclaims_alli/list';
    echo view('templete',$data);
  }
  public function sendsms()
  {
    $data['page']='policyrenewals/sendsms';
    echo view('templete',$data);
  }
  public function sendemail()
  {
    $data['page']='policyrenewals/sendemail';
    echo view('templete',$data);
  }
  public function add()
  {
    if (isset($_POST['action'])) {
      if ($_POST['action'] == 'fetch') {
       $data['postdata']=$_POST;
       $M_capturereceipt = new Models\CaptureReceiptModel();
       $data['risk_note'] = $M_capturereceipt->where(['risk_note_no'=>$_POST['Risk_Note']])->first();
      if ($data['risk_note']) {
        $M_quotation = new Models\QuotationModel();
        $data['quotation'] = $M_quotation->where(['id'=>$data['risk_note']['quot_id']])->first();
        
        $M_client = new Models\ClientModel();
        $data['client'] = $M_client->where(['id'=>$data['quotation']['fk_client_id']])->first();
        $M_quotation->select('insurance_quotation.*,capture_receipt.risk_note_no,clients.email');
        $M_quotation->join('capture_receipt', 'capture_receipt.quot_id = insurance_quotation.id');
        $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id');
        
        $data['quotationdata'] = $M_quotation->where(['insurance_quotation.fk_client_id'=>$data['client']['id']])->findAll();
       // echo "<pre>";print_r($data['quotationdata']);exit;
      }
    }else {
      if ($_POST['quot_id']) {
        $insert = $_POST;
    // echo "<pre>";print_r($insert);exit;
 $session=session();
      $session->setFlashdata('update', "Successfully Record Inserted");
        $M_manageclaims = new Models\ManageClaimsInsurerModel();
        if ($M_manageclaims->insert($insert)) {
          return redirect()->to(site_url('manageclaims_alli'));
        }
      }
    }
    }
    $M_branch = new Models\BranchModel();
    $data['branches'] = $M_branch->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $M_insurancecompany = new Models\InsuranceCompanyModel();
    $data['insurancecompany'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $M_insuranceType = new Models\InsuranceTypeModel();
		$data['insuranceType'] = $M_insuranceType->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $M_claimsdocumentschecklist = new Models\ClaimsDocumentsChecklistModel();
		$data['claimsdocumentschecklist'] = $M_claimsdocumentschecklist->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    //echo "<pre>"; print_r($data['claimsdocumentschecklist']); exit;
    $data['page']='manageclaims_alli/add';
    echo view('templete',$data);
  }
  public function search()
  {
    $M_insurancecompany = new Models\InsuranceCompanyModel();
    $data['insurancecompanys'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $M_manageclaims = new Models\ManageClaimsInsurerModel();
    $M_manageclaims->like('Insured_Name',$_POST['insured_name']);
    $M_manageclaims->like('Risk_Note',$_POST['risknote']);
    $manageclaims = $M_manageclaims->where(['is_deleted'=>0])->findAll();
  $ret=array();
    foreach ($manageclaims as $key) {
      $M_quotation = new Models\QuotationModel();
      $M_quotation->select('insurance_quotation.*,insurance_company.insurance_company,clients.client_name');
      $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
      $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
      $quot = $M_quotation->where(['insurance_quotation.is_deleted'=>0,'insurance_quotation.id'=>$key['quot_id']])->first();
   // echo "<pre>";print_r($manageclaims);exit;
      $key['insurance_company']=$quot['insurance_company'];
      $key['client_name']=$quot['client_name'];
      $ret[]=$key;
    }
    $data['list']=$ret;
   $data['page']='manageclaims_alli/list';
    echo view('templete',$data);
 }
}
?>
