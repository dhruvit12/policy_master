<?php namespace App\Controllers;
use CodeIgniter\Controller;
use Config\Email;
use Config\Services;
use App\Models;

class Communications extends BaseController
{
  public function __construct()
  {

  }

  public function index()
  {
    $session = session();
    if (!isset($_SESSION['userdata'])) {
     return redirect()->to(site_url('auth'));
   }
   $M_emailSmsHistory = new Models\EmailSmsHistoryModel();
   $data['list'] = $M_emailSmsHistory->findAll();
   $data['page']='communications/list';
   echo view('templete',$data);
 }
 public function sms_greetings()
 {
  $session = session();
  if (!isset($_SESSION['userdata'])) {
   return redirect()->to(site_url('auth'));
 }
 $M_client = new Models\ClientModel();
 $data['client'] = $M_client->where(['status'=>1,'is_deleted'=>0])->findAll();
 $M_client_type = new Models\Client_typeModel();
 $data['client_type'] = $M_client_type->where(['is_deleted'=>0,'is_active'=>1])->findAll();
 $data['page']='communications/sms_greetings';
 echo view('templete',$data);
}
public function email_cover_notes()
{
  $session = session();
  if (!isset($_SESSION['userdata'])) {
   return redirect()->to(site_url('auth'));
 }
 $M_insurancecompany = new Models\InsuranceCompanyModel();
 $data['insurancecompany'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
 $data['page']='communications/email_cover_notes';
 echo view('templete',$data);
}
public function send_sms()
{
  $insert=$_POST;
  $M_client = new Models\ClientModel();
  $client = $M_client->where(['id'=>$_POST['client_id'],'is_deleted'=>0])->first();
  $mobile_number=explode(',',$client['mobile_number']);
  $insert['mobile_no']=$mobile_number[0];
  $M_emailSmsHistory = new Models\EmailSmsHistoryModel();
  $M_emailSmsHistory->insert($insert);
  return redirect()->to(site_url('communications/sms_greetings'));
}
public function search()
{
 $data['data']=array('mode'=>$_POST['mode'],'receiver'=>$_POST['receiver'],'body'=>$_POST['body'],'status'=>$_POST['status'],'description'=>$_POST['description'],'date_from'=>$_POST['date_from'],'date_to'=>$_POST['date_to']);
 $M_quotation = new Models\EmailSmsHistoryModel();
 $M_quotation->like('mode',$_POST['mode']);
 $M_quotation->like('email',$_POST['receiver']);
 $M_quotation->like('message',$_POST['body']);
 $M_quotation->like('status',$_POST['status']);
 if(!empty($_POST['date_from']) && !empty($_POST['date_to']))
 {
  $data['list']=$M_quotation->where('created_at >=',$_POST['date_from'])->where('created_at <=',$_POST['date_to'])->where(['is_active'=>1,'is_deleted'=>0])->findAll();
}else
{
 $data['list']=$M_quotation->where(['is_active'=>1,'is_deleted'=>0])->findAll();
} 
// echo "<pre>";print_r($M_quotation->getLastQuery()->getQuery());exit;
$data['page']='communications/list';
echo view('templete',$data);
}
}

?>
