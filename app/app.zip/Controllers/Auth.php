<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use Config\Email;
use Config\Services;
use App\Models;

class Auth extends BaseController
{
	/**
	 * Access to current session.
	 *
	 * @var \CodeIgniter\Session\Session
	 */
	protected $session;

	/**
	 * Authentication settings.
	 */
	protected $config;


    //--------------------------------------------------------------------

	public function __construct()
	{
	}

	public function index()
	{
		$session = session();
		if (isset($_SESSION['userdata'])) {
			return redirect()->to(site_url('dashboard'));
		}
		return view('auth/login');
	}

	public function passwordChange()
	{
		$session = session();
		if (!isset($_SESSION['userdata'])) {
			return redirect()->to(site_url('auth'));
		}
		$data['page']='auth/change_password';
		echo view('templete',$data);
	}


	public function changePassword()
	{
		// echo "<pre>"; print_r($_POST); exit;
		$session = session();
		$userdata = $session->get('userdata');
		$auth = new Models\AuthModel();
		if ($auth->where(['id'=>$userdata['id'],'password'=>hash ( "sha256", $_POST['current_password'])])->first()) {
			if ($_POST['new_password'] == $_POST['confirm_password']) {
				if ($auth->update($userdata['id'], ['password'=>hash ( "sha256", $_POST['confirm_password'])])) {
					$userdata['password']=hash ( "sha256", $_POST['confirm_password']);
					$session->set('userdata',$userdata);
					$session->setFlashdata('error_class', "success");
					$session->setFlashdata('error', "Confirm Password change Successfully");
					return redirect()->to(site_url('auth/passwordChange'));
				}
			}else {
				$session->setFlashdata('error_class', "warning");
				$session->setFlashdata('error', "Confirm Password not match!");
				return redirect()->to(site_url('auth/passwordChange'));
			}
		}else {
			$session->setFlashdata('error_class', "warning");
			$session->setFlashdata('error', "Invalid User Current Password!");
			return redirect()->to(site_url('auth/passwordChange'));
		}
	}

	public function verifyuser(){
		$session = session();
		$auth = new Models\AuthModel();
		$user = $auth->where(['email'=>$_POST['email'],'password'=>hash ( "sha256", $_POST['password'])])->first();
		if (is_null($user)) {
			$session->setFlashdata('error', "Invalid User!");
			return redirect()->to(site_url('auth'));
		}else {
			$M_user_role = new Models\User_RoleModel();
			$role = $M_user_role->where(['id'=>$user['fk_role_id']])->first();
			$user['role']=$role['role_type'];
			// if ($user['role'] == 'company') {
			// 	$M_insurancecompany = new Models\InsuranceCompanyModel();
		  //   $insurancecompany = $M_insurancecompany->where(['email'=>$user['email']])->first();
		  //   $user['insurancecompany_id'] = $insurancecompany['id'];
			// }
			// $user['logged_in']=TRUE;
			// echo "<pre>"; print_r($user); exit;
			// $session->set($user);
			$session->set('userdata',$user);
			// echo "<pre>"; print_r($session->get('userdata')); exit;
			return redirect()->to(site_url('dashboard'));
		}
	}

	public function logout($value='')
	{
		$session = session();
		$session->destroy();
		return redirect()->to(site_url('auth'));
	}
}
