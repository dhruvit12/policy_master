<?php namespace App\Controllers;
use CodeIgniter\Controller;
use Config\Email;
use Config\Services;
use App\Models;

class Excelreports extends BaseController
{
  public function __construct()
  {

  }
  public function index()
  {
    $session = session();
    if (!isset($_SESSION['userdata'])) {
     return redirect()->to(site_url('auth'));
   }
   $data['page']='excelreports/excelreports';
      // print_r($data); exit;
   $M_excelreportstype = new Models\ExcelReportsType();
   $data['excelreportstype'] = $M_excelreportstype->where(['is_deleted'=>0])->findAll();
   $M_insurancecompany = new Models\InsuranceCompanyModel();
   $data['insurancecompany'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
   $M_branch = new Models\BranchModel();
   $data['branches'] = $M_branch->where(['is_active'=>1,'is_deleted'=>0])->findAll();
   $M_client = new Models\ClientModel();
   $data['client'] = $M_client->where(['status'=>1,'is_deleted'=>0])->findAll();
   $M_insuranceType = new Models\InsuranceTypeModel();
   $data['insuranceType'] = $M_insuranceType->where(['is_active'=>1,'is_deleted'=>0])->findAll();
   $M_businesstype = new Models\BusinessTypeModel();
   $data['businesstype'] = $M_businesstype->where(['is_active'=>1,'is_deleted'=>0])->findAll();
   $M_currency = new Models\CurrencyModel();
   $data['currencies'] = $M_currency->where(['is_active'=>1])->findAll();

   echo view('templete',$data);
 }
 public function get_reports_type()
 {
  $M_excelreportstype = new Models\ExcelReportsType();
    // print_r($_POST['search_reports']); exit;
  if ($_POST['search_reports']) {
    $M_excelreportstype->like('excel_reports_type',$_POST['search_reports']);
  }
  $reportstype = $M_excelreportstype->where(['is_deleted'=>0,'is_active'=>1])->findAll();
  $ret = '';
  foreach ($reportstype as $key) {
    $ret .= '<li data-id="'.$key['id'].'">'.$key['excel_reports_type'].'</li>';
  }
  echo $ret;
}
}

?>
