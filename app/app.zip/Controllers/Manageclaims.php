<?php namespace App\Controllers;
use CodeIgniter\Controller;
use Config\Email;
use Config\Services;
use App\Models;

class Manageclaims extends BaseController
{
  public function __construct()
  {
 $session = session();
    if (!isset($_SESSION['userdata'])) {
     return redirect()->to(site_url('auth'));
   }
  }
  public function index()
  {
    $session = session();
    if (!isset($_SESSION['userdata'])) {
     return redirect()->to(site_url('auth'));
   }
   $M_insurancecompany = new Models\InsuranceCompanyModel();
   $data['insurancecompany'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
   $M_manageclaims = new Models\ManageClaimsModel();
   $manageclaims = $M_manageclaims->where(['is_deleted'=>0])->findAll();
   $ret=array();
   foreach ($manageclaims as $key) {
    $M_quotation = new Models\QuotationModel();
    $M_quotation->select('insurance_quotation.*,insurance_company.insurance_company,clients.client_name,manage_claims.claimant_name');
    $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
    $M_quotation->join('manage_claims', 'manage_claims.quot_id = insurance_quotation.id','left');
    $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
    $quot = $M_quotation->where(['insurance_quotation.is_deleted'=>0,'insurance_quotation.id'=>$key['quot_id']])->first();
    $key['quot_id']=$quot['id'];
      //echo "<pre>";print_r($quot);exit;
    $key['insured_name']=$quot['insured_name'];
    $key['insurance_company']=$quot['insurance_company'];
    $key['client_name']=$quot['client_name'];
    $ret[]=$key;
  }
  $data['list']=$ret;
 // echo "<pre>"; print_r($data['list']); exit;
  $data['page']='manageclaims/list';
  echo view('templete',$data);
}
public function sendsms()
{
  $data['page']='policyrenewals/sendsms';
  echo view('templete',$data);
}
public function sendemail()
{
  $data['page']='policyrenewals/sendemail';
  echo view('templete',$data);
}
public function add()
{
   if (isset($_POST['action'])) {
   if ($_POST['action'] == 'fatch') {
    $data['postdata']=$_POST;
      // echo "<pre>";print_r($data['postdata']);exit;
    $M_capturereceipt = new Models\CaptureReceiptModel();
    $data['risk_note'] = $M_capturereceipt->where(['risk_note_no'=>$_POST['risk_note_no']])->first();
    if ($data['risk_note']) {
      $M_quotation = new Models\QuotationModel();
      $data['quotation'] = $M_quotation->where(['id'=>$data['risk_note']['quot_id']])->first();
      $M_client = new Models\ClientModel();
      $data['client'] = $M_client->where(['id'=>$data['quotation']['fk_client_id']])->first();
      $M_quotation->select('insurance_quotation.*,capture_receipt.risk_note_no');
      $M_quotation->join('capture_receipt', 'capture_receipt.quot_id = insurance_quotation.id');
      $data['quotationdata'] = $M_quotation->where(['insurance_quotation.fk_client_id'=>$data['client']['id']])->findAll();
    }
      // echo "<pre>"; print_r($data); exit;
  }else {

    if ($_POST['quot_id']) {
      $insert = $_POST;
      $insert['claimsdocuments']=implode(',',$insert['claimsdocuments']);
        // echo "<pre>"; print_r($insert); exit;
      $M_manageclaims = new Models\ManageClaimsModel();
      if ($M_manageclaims->insert($insert)) {
         $session=session();
      $session->setFlashdata('update', "Successfully Record Inserted");
        return redirect()->to(site_url('manageclaims'));
      }
    }
  }
}
$M_branch = new Models\BranchModel();
$data['branches'] = $M_branch->where(['is_active'=>1,'is_deleted'=>0])->findAll();
$M_insurancecompany = new Models\InsuranceCompanyModel();
$data['insurancecompany'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
$M_insuranceType = new Models\InsuranceTypeModel();
$data['insuranceType'] = $M_insuranceType->where(['is_active'=>1,'is_deleted'=>0])->findAll();
$M_claimsdocumentschecklist = new Models\ClaimsDocumentsChecklistModel();
$data['claimsdocumentschecklist'] = $M_claimsdocumentschecklist->where(['is_active'=>1,'is_deleted'=>0])->findAll();
$data['page']='manageclaims/add';
echo view('templete',$data);
}
public function search()
{
 $data['datas']=array('insured_name'=>$_POST['insured_name'],'claimant_name'=>$_POST['claimant_name'],'risk_note'=>$_POST['risk_note'],'cover_info'=>$_POST['cover_info'],'status'=>$_POST['status'],'company_name'=>$_POST['company_name'],'date_from'=>$_POST['date_from'],'date_to'=>$_POST['date_to']);
  $M_insurancecompany = new Models\InsuranceCompanyModel();
  $data['insurancecompany'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
  $M_quotation = new Models\QuotationModel();
  $M_quotation->select('manage_claims.risk_note_no,manage_claims.claimant_name,manage_claims.current_status,manage_claims.record_status,insurance_quotation.*,insurance_company.insurance_company,clients.client_name');
  $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
  $M_quotation->join('manage_claims', 'manage_claims.quot_id = insurance_quotation.id','left');
  $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
  $M_quotation->like('insurance_quotation.insured_name',$_POST['insured_name']);
  $M_quotation->like('manage_claims.claimant_name',$_POST['claimant_name']);
  $M_quotation->like('manage_claims.risk_note_no',$_POST['risk_note']);
  $M_quotation->like('manage_claims.current_status',$_POST['status']);
  if(!empty($_POST['date_from']) && !empty($_POST['date_to']))
  {
    $quot=$M_quotation->where('manage_claims.reported_date >=',$_POST['date_from'])->where('manage_claims.reported_date <=',$_POST['date_to'])->where(['manage_claims.is_active'=>1,'manage_claims.is_deleted'=>0])->findAll();
  }else
  {
   $quot=$M_quotation->where(['manage_claims.is_active'=>1,'manage_claims.is_deleted'=>0])->findAll();
 }
 echo "<pre>";print_r($M_quotation->getLastQuery()->getQuery());exit;
 $data['list']=$quot;
 $data['page']='manageclaims/list';
 echo view('templete',$data);
 

}
}
?>
