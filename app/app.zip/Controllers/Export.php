<?php namespace App\Controllers;
use CodeIgniter\Controller;
use Config\Email;
use Config\Services;
use App\Models;
use App\Libraries\Ciqrcode; // Import library
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelLow;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Label\Label;
use Endroid\QrCode\Logo\Logo;
use Endroid\QrCode\RoundBlockSizeMode\RoundBlockSizeModeMargin;
use Endroid\QrCode\Writer\PngWriter;

class Export extends BaseController
{
  public function __construct()
  {
    $this->db = \Config\Database::connect();

  }
  public function payment($id)
  {
    $this->M_directpayment = new Models\DirectPaymentNewModel();
 $this->M_directpayment->select('direct_payment1.*,clients.client_name,clients.address,clients.tin,insurance_company.insurance_company,currency.code,payment_mode.name as paymentmode');
 $this->M_directpayment->join('insurance_company', 'insurance_company.id = direct_payment1.company_id','left');
 $this->M_directpayment->join('currency', 'currency.id = direct_payment1.currency_id','left');
 $this->M_directpayment->join('clients', 'clients.id = direct_payment1.client_id','left');
 $this->M_directpayment->join('payment_mode', 'payment_mode.id = direct_payment1.mode','left');
 $payment= $this->M_directpayment->where(['direct_payment1.is_active'=>1,'direct_payment1.is_deleted'=>0,'direct_payment1.id'=>$id])->first();
 //echo "<pre>";print_r($payment);exit;
 require_once FCPATH.'public/mpdf/autoload.php';
  $html = '<style>
p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td class="full" style="height: 170px;border: 1px solid;padding: 5px;width:600px;">
  
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo.png" alt="" style="height:200px;margin-left: 400px;">

  </td>
  </tr>
   <tr>
  <td class="full" style="border: 1px solid;padding:10px;background-color: #000;text-align: center;">
  <p style="color: #fff;margin: auto;font-size: 16px;">Receipt</p>
  </td>
  </tr>
   </table>
   <table>

  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>No/Cl : </b>RICL121735</p>
  </td>
  <td width="50%" style="border: 1px solid;padding:10px;text-align: right;border-left:none;">
  <p style="margin: auto;font-size: 12px;" > Date : <span style="padding:4px;">
        <input type="text" value='.date("d-M-Y").'></span></p>
  </td>
  </tr>

  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>Payment To :  </b> &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" value='.$payment['client_name'].' > <br>
   <b>Address:</b>&nbsp;&nbsp;&nbsp;&nbsp;<textarea type="text">'.$payment['address'].'</textarea>
   </p>
  </td>
  <td style="border: 1px solid;border-left:none;"></td>
  </tr>
<tr>
  <td width="50%" style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>Payment Mode :  </b> &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" value='.$payment['paymentmode'].' > <br>
   <b>Reference No:</b>&nbsp;&nbsp;&nbsp;&nbsp;<textarea type="text">'.$payment['reference_number'].'</textarea>
   </p>
  </td>
  <td style="border: 1px solid;border-left:none;"></td>
  </tr>
  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>Notes :  </b> &nbsp;&nbsp;&nbsp;&nbsp;<textarea type="text">'.$payment['notes'].'</textarea> <br>
   
   </p>
  </td>
   <td style="border: 1px solid;border-left:none;"></td>
  <tr>
  <tr>
  </table>
  <table>
  <tr>
   <td width="50%" style="border: 1px solid;text-align: right;padding:10px;border:none;border-left:1px solid;border-right:1px solid">
  <p style="margin: auto;font-size: 12px;" > <span style="padding:4px;"> Issued By ,MILMAR-CEO</span> </p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;border-right:none;border-right:none;border-top:none;">
  <p style="margin: auto;font-size: 12px;"><b>'.$payment['code'].' :  </b> &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" value='.$payment['amount'].' > </td>
    <td width="50%" style="border: 1px solid;text-align: right;padding:10px;border:none;border-top:1px solid;border-right:1px solid">
  <p style="margin: auto;font-size: 12px;" > <span style="padding:4px;"> FOR MILMAR Insurance Consultants Ltd</span> </p>
  </td>
  </tr>
  <tr>
  <td width="50%" style="padding:5px;border:1px solid;border-top:none;border-right:none">
  <p style="margin: auto;font-size: 12px;"><b>TIN : </b><b>'.$payment['tin'].'</b></p>
  </td>
   <td style="border: 1px solid;border-left:none;"></td>
 </tr>
  </table>';
    $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
    $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td width="75%"><p style="font-size: 11px;">Powered by ITL (Imatic Technologies Limited) from Smart Policy System</p></td>
    <td width="25%" style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');
 
  $mpdf->WriteHTML($html);
  $filename = 'QUOTATION-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/payment/REPORT-'.$filename);
return redirect()->to(base_url('public/pdf/payment/REPORT-'.$filename));
  }
  public function receipts($id)
  {
   $M_receipts = new Models\Receipts_model();
   $M_receipts->select('receipts_insurer.*,currency.name');
   $M_receipts->join('currency', 'currency.id = receipts_insurer.currency','left');
   $quotation = $M_receipts->where(['receipts_insurer.id'=>$id])->first();
   require_once FCPATH.'public/mpdf/autoload.php';
   $html = '<style>
   p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td class="full" style="height: 170px;border: 1px solid;padding: 5px;width:600px;">
  
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo.png" alt="" style="height:200px;margin-left: 400px;">

  </td>
  </tr>
   <tr>
  <td class="full" style="border: 1px solid;padding:10px;background-color: #000;text-align: center;">
  <p style="color: #fff;margin: auto;font-size: 16px;">Receipt</p>
  </td>
  </tr>
   </table>
   <table>

  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>Tax Invoice No : </b>RICL121735</p>
  </td>
  <td width="50%" style="border: 1px solid;padding:5px;text-align: right;border-left:none;">
  <p style="margin: auto;font-size: 12px;"><b>Date : </b>'.date("d-M-Y").'</p>
  </td>
  </tr>
<tr>
  </table>';
  $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
  $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td width="75%"><p style="font-size: 11px;">Powered by ITL (Imatic Technologies Limited) from Smart Policy System</p></td>
    <td width="25%" style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');
 
  $mpdf->WriteHTML($html);
  $filename = 'QUOTATION-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/quotation/REPORT-'.$filename);
return redirect()->to(base_url('public/pdf/quotation/REPORT-'.$filename));
  }
  public function endorsement($id)
  {
        $session = session();
    if (!isset($_SESSION['userdata'])) {
     return redirect()->to(site_url('auth'));
   }

$M_endorsement = new Models\QuotationModel();
   $M_endorsement->select('*');
    $M_endorsement->join('capture_receipt', 'capture_receipt.quot_id = insurance_quotation.id','left');
   $M_endorsement->join('branch_details', 'branch_details.id = insurance_quotation.fk_branch_id','left');
   $M_endorsement->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
   $M_endorsement->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
   $endorsement= $M_endorsement->where(['insurance_quotation.is_deleted'=>0])->first();
   // echo "<pre>";print_r($endorsement);echo "<pre>";
   //echo "<pre>";print_r($M_endorsement->getLastQuery()->getQuery());exit;
   $M_endorsementType = new Models\EndorsementTypeModel();
   $endorsementType = $M_endorsementType->where(['is_deleted'=>0,'is_active'=>1])->first();

     
   require_once FCPATH.'public/mpdf/autoload.php';
   $html = '<style>
   p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td class="full" style="height: 170px;border: 1px solid;padding: 5px;width:600px;">
  
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo.png" alt="" style="height:200px;margin-left: 400px;">

  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding:10px;background-color: #000;text-align: center;">
  <p style="color: #fff;margin: auto;font-size: 16px;">ENDORSEMENT REPORT</p>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;padding:10px;">
  <table>
  <tr>
  <td>
  <p style="font-size: 14px;"> <b>Endorsement ID. : '.$endorsement['id'].'</b> </p>
  </td>
  <td align=center>
  <p style="font-size: 14px;"> <b>Payment Reference No. : SPE00670265171</b> </p>
  </td>
  <td style="text-align: right;">
  <p style="font-size: 14px;"> <b>Date : '.date("d-M-Y").'</b> </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;">
  <table>
  <tr>
  <td style="border-right: 1px solid;width:50%;padding: 10px;">

  <p style="font-size: 12px;"><b style="font-size: 14px;">Client Name :</b> '.$endorsement['title'].'. '.$endorsement['client_name'].'</p>
  <p style="font-size: 12px;"><b style="font-size: 14px;">Address :</b> <BR><BR>'.$endorsement['address'].' Mobile: '.explode(',',$endorsement['mobile_number'])[0].',</p>

  </td>
  <td style="width:50%;">
  <table>
  <tr>
  <td style="padding: 8px;border-bottom: 1px solid;">
  <p style="font-size: 12px;"><b style="font-size: 14px;">Cover Period :</b> '.date("d-M-Y",strtotime($endorsement['date_from'])).' - to - '.date("d-M-Y",strtotime($endorsement['date_to'])).'</p>
  </td>
  </tr>
  <tr>
  <td style="padding: 8px;">
  <p style="font-size: 12px;"><b style="font-size: 14px;">Insurer Name :</b><br><b> '.strtoupper($endorsement['insurance_company']).'</b></p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;">
  <table>
  <tr>
  <th style="width: 40%;border: 1px solid;border-top:none;border-left:none;">
  Insured Name/ Type of Cover Vehicle Registration/ Make / Model/ Color / Year of Manufacture
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;">
  Sum Insured / Windscreen / Accessories
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;">
  Gross Premium / Other Fee
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;">
  VAT Premium
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;">
  Policy fund / Tran / Ins Levy / Stamp Duty
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;border-right:none;">
  Net Preimum(in TZS)
  </th>
  </tr>';
  $bulder = $this->db->table('tbl_insurance_sub_type');
  $row = $bulder->getWhere(['id' => $endorsement['fk_insurance_type_id']])->getRowArray();
  if ($row['main'] == 1) {
    $bulder = $this->db->table('insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $endorsement['id']])->getResultArray();
  }elseif ($row['main'] == 2) {
    $bulder = $this->db->table('vehicle_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $endorsement['id']])->getResultArray();
  } elseif ($row['main'] == 3) {
    $bulder = $this->db->table('life_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $endorsement['id']])->getResultArray();
  }
         // echo '<pre>'; print_r($res);  exit;
  $sum['sum_insured'] = 0;
  $sum['premium'] = 0;
  if(isset($res[0]['sum_insured']))
  {
  foreach ($res as $key) {
    $html .= '<tr>
    <td style="width:40%;border: 1px solid;border-left:none;border-right:none;">
    <p style="font-size: 12px;">'.$endorsement['insured_name'].'</p>
    </td>
    <td style="width:12%;border: 1px solid;border-left:1px solid black;text-align: right;">
    <p style="font-size: 12px;">'.$key['sum_insured'] .'</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    <p style="font-size: 12px;">0.00</p>
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;border-right:none;text-align: right;">
    <p style="font-size: 12px;">'.$key['premium'].'</p>
    </td>
    </tr>';
    $sum['sum_insured'] = $sum['sum_insured']+$key['sum_insured'];
    $sum['premium'] = $sum['premium']+$key['premium'];
  }
}
  if(isset($res[0]['sum_assured']))
  {
  foreach ($res as $key) {
    $html .= '<tr>
    <td style="width:40%;border: 1px solid;border-left:none;border-right:none;">
    <p style="font-size: 12px;">'.$endorsement['insured_name'].'</p>
    </td>
    <td style="width:12%;border: 1px solid;border-left:1px solid black;text-align: right;">
    <p style="font-size: 12px;">'.$key['sum_assured'] .'</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    <p style="font-size: 12px;">0.00</p>
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;border-right:none;text-align: right;">
    <p style="font-size: 12px;">'.$key['premium'].'</p>
    </td>
    </tr>';
    $sum['sum_insured'] = $sum['sum_insured']+$key['sum_assured'];
    $sum['premium'] = $sum['premium']+$key['premium'];
  }
}
  $html .= '<tr>
  <td style="width:40%;border-bottom:none;border-right:1px solid;padding: 8px;">
  <p style="font-size: 14px;font-weight: bold;">SUB TOTAL</p>
  </td>
  <td style="width:12%;border-right:1px solid;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$sum['sum_insured'].'</p>
  </td>
  <td style="width:12%;border-right:1px solid;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$endorsement['other_fee'].'</p>
  </td>
  <td style="width:12%;border-right:1px solid;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$endorsement['vat'].'</p>
  </td>
  <td style="width:12%;border-right:1px solid;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$endorsement['policy_holder_fund'].'</p>
  </td>
  <td style="width:12%;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$sum['premium'].'</p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;height: 20px;">
  <table>
  <tr>
  <td style="padding: 8px;">
  <p style="font-size: 14px;"> <b>ADMINISTRATION CHARGES</b> </p>
  </td>
  <td style="text-align: right;padding: 8px;">
  <p style="font-size: 14px;"> <b> '.$endorsement['administrative_charges'].'</b> </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;height: 20px;padding: 8px;">
  <table>
  <tr>
  <td>
  <p style="font-size: 14px;"> <b>TOTAL RECEIVABLE</b> </p>
  </td>
  <td style="text-align: right;">
  <p style="font-size: 14px;"> <b> '.$endorsement['total_receivable'].'</b> </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;height: 20px;padding: 8px;">
  <p style="font-size: 14px;"><b>TIN: '.$endorsement['tin'].',</b></p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 15px 5px;">
  <table>
  <tr>
  <td style="padding: 3px 0 10px 0;">
  <p style="font-size: 12px;"> For payment through NMB Channels: </p>
  <p style="font-size: 12px;"> Your NMB payment reference # is <b>SPQ0002026524698</b>. Your broker shall advise you on the payment guidelines. </p>
  </td>
  </tr>
  <tr>
  <td>
  <p style="font-size: 12px;"> FOR PAYMENT THROUGH SELCOM PAY:Reference number has not been generated, kindly click on \'Digital Payment\' button
  on endorsement screen & select \'Selcom\' option to generate payment reference number. </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;height: 20px;padding: 15px 5px;">
  <table>
  <tr>
  <td style="padding: 3px 0 10px 0;">
  <p style="font-size: 12px;"> A. I&M Bank (T) Limited A/C </p>
  <p style="font-size: 12px;"> Tshs - 010006941101 Swift Code: IMBLTZTZ </p>
  <p style="font-size: 12px;"> USD - 010006940111 Swift Code: IMBLTZTZ </p>
  </td>
  </tr>
  <tr>
  <td style="padding: 3px 0 10px 0;">
  <p style="font-size: 12px;"> A. I&M Bank (T) Limited A/C </p>
  <p style="font-size: 12px;"> Tshs - 010006941101 Swift Code: IMBLTZTZ </p>
  <p style="font-size: 12px;"> USD - 010006940111 Swift Code: IMBLTZTZ </p>
  </td>
  </tr>
  <tr>
  <td>
  <p style="font-size: 12px;"> A. I&M Bank (T) Limited A/C </p>
  <p style="font-size: 12px;"> Tshs - 010006941101 Swift Code: IMBLTZTZ </p>
  <p style="font-size: 12px;"> USD - 010006940111 Swift Code: IMBLTZTZ </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 15px 5px;">
  <p style="font-size: 14px;"><b>Notes:</b></p>
  <p style="font-size: 12px;">The payment should be made in favor of the insurance company <b>Reliance Insurance Company (Tanzania) Limited</b></p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 15px 5px;">
  <p style="font-size: 14px;">6 MONTHS SUBJECT TO EXTENSION BEFORE EXPIRY AND BALANCE PAYMENT OF TZS 226,800.00</p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 5px;">
  <table>
  <tr>
  <td style="width: 65%;">
  </td>
  <td style="width: 35%;text-align: right;">
  <p style="font-size: 14px;"> <b>ISSUED BY, IBRAHIM N. MORAWEJ</b> </p>
  </td>
  </tr>
  <tr>
  <td style="width: 65%;height: 100px;">
  </td>
  <td style="width: 35%;height: 100px;border-bottom: 1px solid;">
  </td>
  </tr>
  <tr>
  <td style="width: 65%;">
  </td>
  <td style="width: 35%;text-align: right;">
  <p style="font-size: 11px;"> <b>For, Milmar Insurance Consultants Ltd</b> </p>
  </td>
  </tr>
  <tr>
  <td style="width: 65%;height: 50px;">
  </td>
  <td style="width: 35%;height: 50px;">
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <table>
  <tr>

  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;padding:7px;">
  <table>
  <tr>
  <td>
  <p style="font-size: 12px;"> <b>Quote No. : '.$endorsement['quotation_id'].'</b> </p>
  </td>
  <td style="text-align: right;">
  <p style="font-size: 12px;"> <b>Date : '.date("d-M-Y").'</b> </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;border-bottom: none;padding: 5px;">
  <p style="font-size: 12px;"><b>Customer Declaration:</b> </p>
  <p style="font-size: 11px;">1. I/We declare that the above quote is given to me/us on the information provided by me/us. </p>
  <p style="font-size: 11px;">2. I/We declare to the best of my/our knowledge and belief that the information given on this quote is true in every respect. </p>
  <p style="font-size: 11px;">3. I/We agree that this proposal and declaration shall be the basis of the contract between me/us and the Insurer. </p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border-right: 1px solid;border-left: 1px solid;padding: 15px;">
  <table>
  <tr>
  <td style="width:200px;height:40px;border-bottom: 1px solid;">
  </td>
  <td style="height:40px;">
  </td>
  <td style="text-align: right;width:200px;height:40px;border-bottom: 1px solid;">
  </td>
  </tr>
  <tr>
  <td style="width:200px;">
  <p style="font-size: 14px;"> Signature </p>
  </td>
  <td style="">
  </td>
  <td style="width:200px;">
  <p style="font-size: 14px;"> Date </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 5px;">
  <p style="font-size: 12px;"><b>IMPORTANT NOTICE: Failure to disclose material facts could result in your contract being invalidated/cancelled, a claim not
  being paid or difficulty in obtaining insurance in the future. If you are in doubt as to whether a fact is material you should
  disclose it. The Insurer reserves the right to decline any proposal.</b> </p>
  </td>
  </tr>
  </table>';

  $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
  $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td width="75%"><p style="font-size: 11px;">Powered by ITL (Imatic Technologies Limited) from Smart Policy System</p></td>
    <td width="25%" style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');
   
  $mpdf->WriteHTML($html);
  $filename = 'QUOTATION-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/quotation/REPORT-'.$filename);
return redirect()->to(base_url('public/pdf/quotation/REPORT-'.$filename));
}
  public function quotation($id)
  {
        $session = session();
    if (!isset($_SESSION['userdata'])) {
     return redirect()->to(site_url('auth'));
   }
   $M_quotation = new Models\QuotationModel();
   $M_quotation->select('insurance_quotation.*,branch_details.branch_name,clients.client_name,clients.title,clients.tin,clients.mobile_number,insurance_company.insurance_company,tbl_insurance_sub_type.name as insurance_type');
   $M_quotation->join('branch_details', 'branch_details.id = insurance_quotation.fk_branch_id','left');
   $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
   $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
   $M_quotation->join('tbl_insurance_sub_type', 'tbl_insurance_sub_type.id = insurance_quotation.fk_insurance_type_id','left');
   $quotation = $M_quotation->where(['insurance_quotation.id'=>$id])->first();
     
   require_once FCPATH.'public/mpdf/autoload.php';
   $html = '<style>
   p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td class="full" style="height: 170px;border: 1px solid;padding: 5px;width:600px;">
  
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo.png" alt="" style="height:200px;margin-left: 400px;">

  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding:10px;background-color: #000;text-align: center;">
  <p style="color: #fff;margin: auto;font-size: 16px;">QUOTATION</p>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;padding:10px;">
  <table>
  <tr>
  <td>
  <p style="font-size: 14px;"> <b>Quote No. : '.$quotation['quotation_id'].'</b> </p>
  </td>
  <td style="text-align: right;">
  <p style="font-size: 14px;"> <b>Date : '.date("d-M-Y").'</b> </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;height: 30px;">
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;">
  <table>
  <tr>
  <td style="border-right: 1px solid;width:50%;padding: 10px;">

  <p style="font-size: 12px;"><b style="font-size: 14px;">Client Name :</b> '.$quotation['title'].'. '.$quotation['client_name'].'</p>
  <p style="font-size: 12px;"><b style="font-size: 14px;">Address :</b> '.$quotation['address'].' Mobile: '.explode(',',$quotation['mobile_number'])[0].',</p>
  </td>
  <td style="width:50%;">
  <table>
  <tr>
  <td style="padding: 8px;border-bottom: 1px solid;">
  <p style="font-size: 12px;"><b style="font-size: 14px;">Cover Period :</b> '.date("d-M-Y",strtotime($quotation['date_from'])).' - to - '.date("d-M-Y",strtotime($quotation['date_to'])).'</p>
  </td>
  </tr>
  <tr>
  <td style="padding: 8px;">
  <p style="font-size: 12px;"><b style="font-size: 14px;">Insurer Name :</b> '.$quotation['insurance_company'].'</p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;">
  <table>
  <tr>
  <th style="width: 40%;border: 1px solid;border-top:none;border-left:none;">
  Insured Name/ Type of Cover Vehicle Registration/ Make / Model/ Color / Year of Manufacture
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;">
  Sum Insured / Windscreen / Accessories
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;">
  Gross Premium / Other Fee
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;">
  VAT Premium
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;">
  Policy fund / Tran / Ins Levy / Stamp Duty
  </th>
  <th style="width:12%;border: 1px solid;border-top:none;border-right:none;">
  Net Preimum(in TZS)
  </th>
  </tr>';
  $bulder = $this->db->table('tbl_insurance_sub_type');
  $row = $bulder->getWhere(['id' => $quotation['fk_insurance_type_id']])->getRowArray();
  if ($row['main'] == 1) {
    $bulder = $this->db->table('insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $quotation['id']])->getResultArray();
  }elseif ($row['main'] == 2) {
    $bulder = $this->db->table('vehicle_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $quotation['id']])->getResultArray();
  } elseif ($row['main'] == 3) {
    $bulder = $this->db->table('life_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $quotation['id']])->getResultArray();
  }
         // echo '<pre>'; print_r($res);  exit;
  $sum['sum_insured'] = 0;
  $sum['premium'] = 0;
  if(isset($res[0]['sum_insured']))
  {
  foreach ($res as $key) {
    $html .= '<tr>
    <td style="width:40%;border: 1px solid;border-left:none;border-right:none;">
    <p style="font-size: 12px;">'.$quotation['insured_name'].'</p>
    </td>
    <td style="width:12%;border: 1px solid;border-left:1px solid black;text-align: right;">
    <p style="font-size: 12px;">'.$key['sum_insured'] .'</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    <p style="font-size: 12px;">0.00</p>
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;border-right:none;text-align: right;">
    <p style="font-size: 12px;">'.$key['premium'].'</p>
    </td>
    </tr>';
    $sum['sum_insured'] = $sum['sum_insured']+$key['sum_insured'];
    $sum['premium'] = $sum['premium']+$key['premium'];
  }
}
  if(isset($res[0]['sum_assured']))
  {
  foreach ($res as $key) {
    $html .= '<tr>
    <td style="width:40%;border: 1px solid;border-left:none;border-right:none;">
    <p style="font-size: 12px;">'.$quotation['insured_name'].'</p>
    </td>
    <td style="width:12%;border: 1px solid;border-left:1px solid black;text-align: right;">
    <p style="font-size: 12px;">'.$key['sum_assured'] .'</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;text-align: right;">
    <p style="font-size: 12px;">0.00</p>
    <p style="font-size: 12px;">0.00</p>
    <p style="font-size: 12px;">0.00</p>
    </td>
    <td style="width:12%;border: 1px solid;border-right:none;text-align: right;">
    <p style="font-size: 12px;">'.$key['premium'].'</p>
    </td>
    </tr>';
    $sum['sum_insured'] = $sum['sum_insured']+$key['sum_assured'];
    $sum['premium'] = $sum['premium']+$key['premium'];
  }
}
  $html .= '<tr>
  <td style="width:40%;border-bottom:none;border-right:1px solid;padding: 8px;">
  <p style="font-size: 14px;font-weight: bold;">SUB TOTAL</p>
  </td>
  <td style="width:12%;border-right:1px solid;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$sum['sum_insured'].'</p>
  </td>
  <td style="width:12%;border-right:1px solid;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$quotation['other_fee'].'</p>
  </td>
  <td style="width:12%;border-right:1px solid;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$quotation['vat'].'</p>
  </td>
  <td style="width:12%;border-right:1px solid;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$quotation['policy_holder_fund'].'</p>
  </td>
  <td style="width:12%;text-align: right;padding: 8px;">
  <p style="font-size: 12px;font-weight: bold;">'.$sum['premium'].'</p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;height: 20px;">
  <table>
  <tr>
  <td style="padding: 8px;">
  <p style="font-size: 14px;"> <b>ADMINISTRATION CHARGES</b> </p>
  </td>
  <td style="text-align: right;padding: 8px;">
  <p style="font-size: 14px;"> <b> '.$quotation['administrative_charges'].'</b> </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;height: 20px;padding: 8px;">
  <table>
  <tr>
  <td>
  <p style="font-size: 14px;"> <b>TOTAL RECEIVABLE</b> </p>
  </td>
  <td style="text-align: right;">
  <p style="font-size: 14px;"> <b> '.$quotation['total_receivable'].'</b> </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;height: 20px;padding: 8px;">
  <p style="font-size: 14px;"><b>TIN: '.$quotation['tin'].',</b></p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 15px 5px;">
  <table>
  <tr>
  <td style="padding: 3px 0 10px 0;">
  <p style="font-size: 12px;"> For payment through NMB Channels: </p>
  <p style="font-size: 12px;"> Your NMB payment reference # is <b>SPQ0002026524698</b>. Your broker shall advise you on the payment guidelines. </p>
  </td>
  </tr>
  <tr>
  <td>
  <p style="font-size: 12px;"> FOR PAYMENT THROUGH SELCOM PAY:Reference number has not been generated, kindly click on \'Digital Payment\' button
  on quotation screen & select \'Selcom\' option to generate payment reference number. </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;height: 20px;padding: 15px 5px;">
  <table>
  <tr>
  <td style="padding: 3px 0 10px 0;">
  <p style="font-size: 12px;"> A. I&M Bank (T) Limited A/C </p>
  <p style="font-size: 12px;"> Tshs - 010006941101 Swift Code: IMBLTZTZ </p>
  <p style="font-size: 12px;"> USD - 010006940111 Swift Code: IMBLTZTZ </p>
  </td>
  </tr>
  <tr>
  <td style="padding: 3px 0 10px 0;">
  <p style="font-size: 12px;"> A. I&M Bank (T) Limited A/C </p>
  <p style="font-size: 12px;"> Tshs - 010006941101 Swift Code: IMBLTZTZ </p>
  <p style="font-size: 12px;"> USD - 010006940111 Swift Code: IMBLTZTZ </p>
  </td>
  </tr>
  <tr>
  <td>
  <p style="font-size: 12px;"> A. I&M Bank (T) Limited A/C </p>
  <p style="font-size: 12px;"> Tshs - 010006941101 Swift Code: IMBLTZTZ </p>
  <p style="font-size: 12px;"> USD - 010006940111 Swift Code: IMBLTZTZ </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 15px 5px;">
  <p style="font-size: 14px;"><b>Notes:</b></p>
  <p style="font-size: 12px;">The payment should be made in favor of the insurance company <b>Reliance Insurance Company (Tanzania) Limited</b></p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 15px 5px;">
  <p style="font-size: 14px;">6 MONTHS SUBJECT TO EXTENSION BEFORE EXPIRY AND BALANCE PAYMENT OF TZS 226,800.00</p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 5px;">
  <table>
  <tr>
  <td style="width: 65%;">
  </td>
  <td style="width: 35%;text-align: right;">
  <p style="font-size: 14px;"> <b>ISSUED BY, IBRAHIM N. MORAWEJ</b> </p>
  </td>
  </tr>
  <tr>
  <td style="width: 65%;height: 100px;">
  </td>
  <td style="width: 35%;height: 100px;border-bottom: 1px solid;">
  </td>
  </tr>
  <tr>
  <td style="width: 65%;">
  </td>
  <td style="width: 35%;text-align: right;">
  <p style="font-size: 11px;"> <b>For, Milmar Insurance Consultants Ltd</b> </p>
  </td>
  </tr>
  <tr>
  <td style="width: 65%;height: 50px;">
  </td>
  <td style="width: 35%;height: 50px;">
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <table>
  <tr>

  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;padding:7px;">
  <table>
  <tr>
  <td>
  <p style="font-size: 12px;"> <b>Quote No. : '.$quotation['quotation_id'].'</b> </p>
  </td>
  <td style="text-align: right;">
  <p style="font-size: 12px;"> <b>Date : '.date("d-M-Y").'</b> </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;border-bottom: none;padding: 5px;">
  <p style="font-size: 12px;"><b>Customer Declaration:</b> </p>
  <p style="font-size: 11px;">1. I/We declare that the above quote is given to me/us on the information provided by me/us. </p>
  <p style="font-size: 11px;">2. I/We declare to the best of my/our knowledge and belief that the information given on this quote is true in every respect. </p>
  <p style="font-size: 11px;">3. I/We agree that this proposal and declaration shall be the basis of the contract between me/us and the Insurer. </p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border-right: 1px solid;border-left: 1px solid;padding: 15px;">
  <table>
  <tr>
  <td style="width:200px;height:40px;border-bottom: 1px solid;">
  </td>
  <td style="height:40px;">
  </td>
  <td style="text-align: right;width:200px;height:40px;border-bottom: 1px solid;">
  </td>
  </tr>
  <tr>
  <td style="width:200px;">
  <p style="font-size: 14px;"> Signature </p>
  </td>
  <td style="">
  </td>
  <td style="width:200px;">
  <p style="font-size: 14px;"> Date </p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding: 5px;">
  <p style="font-size: 12px;"><b>IMPORTANT NOTICE: Failure to disclose material facts could result in your contract being invalidated/cancelled, a claim not
  being paid or difficulty in obtaining insurance in the future. If you are in doubt as to whether a fact is material you should
  disclose it. The Insurer reserves the right to decline any proposal.</b> </p>
  </td>
  </tr>
  </table>';

  $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
  $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td width="75%"><p style="font-size: 11px;">Powered by ITL (Imatic Technologies Limited) from Smart Policy System</p></td>
    <td width="25%" style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');
    // $writer = new PngWriter();
    //     $datas=rand().'dhruvitsagar';
        
    //     $qrCode = QrCode::create($datas)
    //         ->setEncoding(new Encoding('UTF-8'))
    //         ->setErrorCorrectionLevel(new ErrorCorrectionLevelLow())
    //         ->setSize(400)
    //         ->setMargin(10)
    //         ->setRoundBlockSizeMode(new RoundBlockSizeModeMargin())
    //         ->setForegroundColor(new Color(0, 0, 0))
    //         ->setBackgroundColor(new Color(255, 255, 255));
    
    //   $result = $writer->write($qrCode);
    //   // header('Content-Type: image/png '.$result->getMimeType());
    //   header('Content-type: image/png');
    //   header('Content-Disposition: attachment; filename="'.rand().'image.png"',true);
    //                 $html= $result->getString();
    //                echo $html;exit;
 //       $text='dhruvit';
 // $folder=base_url('public/assets/images/');
 // $file_name="/qr.png";
 // $file_name=$folder.$file_name;
 // // print_r($file_name);exit;
 // QrCode::png($text,$file_name);
 // echo'<img src="'.base_url('public/assets/images/qr.png').'" alt="" style="height:200px;margin-left: 400px;">';
 // exit;    
  $mpdf->WriteHTML($html);
  $filename = 'QUOTATION-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/quotation/REPORT-'.$filename);
return redirect()->to(base_url('public/pdf/quotation/REPORT-'.$filename));
}
public function risknote_insurer($id)
{

  $M_quotation = new Models\QuotationModel();
  $M_quotation->select('insurance_quotation.*,branch_details.branch_name,clients.title,clients.client_name,insurance_company.insurance_company,capture_receipt.risk_note_no,capture_receipt.status as capture_receipt_status,insurance_type.insurance_type_name');
  $M_quotation->join('branch_details', 'branch_details.id = insurance_quotation.fk_branch_id','left');
  $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
  $M_quotation->join('capture_receipt', 'capture_receipt.quot_id = insurance_quotation.id');
  $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
  $M_quotation->join('insurance_type', 'insurance_type.id = insurance_quotation.fk_insurance_type_id','left');
  $risknote = $M_quotation->where(['insurance_quotation.id'=>$id])->first();
//echo "<pre>";print_r($risknote);exit;
  require_once FCPATH.'public/mpdf/autoload.php';
  $html = '<style>
  p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td class="full" style="border: 1px solid;padding: 5px;">
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo.png" alt="" style="height:80px;margin: 10px 0;">
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo2.png" alt="" style="float: right;height:80px;margin: 10px 0 10px 200px;">
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding:5px;text-align: center;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">INTERIM COVER NOTE</p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding:3px;text-align: center;">
  <table>
  <tr>
  <td style="width:180px;padding: 4px;">
  <p style="margin: auto;font-size: 14px;font-weight: bold;">RISK NOTE NO :</p>
  </td>
  <td style="width:150px;border: 1px solid;padding:4px;text-align: center;">
  <p style="margin: auto;font-size: 14px;font-weight: bold;">'.$risknote['risk_note_no'].'</p>
  </td>
  <td style="padding: 4px;">
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td rowspan="2" style="width:150px;border: 1px solid;padding:2px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Insured Name</p>
  </td>
  <td rowspan="2" style="width:300px;border: 1px solid;padding:2px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['client_name'].'</p>
  </td>
  <td style="border: 1px solid;padding:2px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Cover Note No</p>
  </td>
  <td style="border: 1px solid;padding:2px;">
  <p style="margin: auto;font-size: 12px;">MLCLG0003762</p>
  </td>
  </tr>

  <tr>
  <td style="border: 1px solid;padding: 5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Policy No</p>
  </td>
  <td style="border: 1px solid;padding: 5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['policy_no'].'</p>
  </td>
  </tr>
  <tr>
  <td style="width:150px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Insurance Type</p>
  </td>
  <td style="width:300px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['insurance_type_name'].'</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Debit No</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['debitnoteno'].'</p>
  </td>
  </tr>
  <tr>
  <td style="width:150px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Account</p>
  </td>
  <td style="width:300px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['title'].' '.$risknote['client_name'].'</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">File No</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['file_no'].'</p>
  </td>
  </tr>
  <tr>
  <td rowspan="2" style="width:150px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Address</p>
  </td>
  <td rowspan="2" style="width:300px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['address'].'</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Tax Invoice No</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">MFRI36290</p>
  </td>
  </tr>
  <tr>
  <td colspan="2" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;">Insurer Name </p>
  <p style="margin: auto;font-size: 11px;">'.$risknote['insurance_company'].' </p>
  </td>
  </tr>
  <tr>
  <td style="width:150px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Cover Period From</p>
  </td>
  <td colspan="3" style="width:300px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.date("d-M-Y",strtotime($risknote['date_from'])).' 12:00AM To '.date("d-M-Y",strtotime($risknote['date_to'])).'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="width:50%;padding: 4px;border: 1px solid;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">DETAILS OF COVERAGE</p>
  </td>
  <td style="width:50%;border: 1px solid;padding:4px;text-align: center;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">DESCRIPTION OF RISK</p>
  </td>
  </tr>
  <tr>
  <td style="width:50%;padding: 4px;border: 1px solid;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['covering_details'].'</p>
  </td>
  <td style="width:50%;border: 1px solid;padding:4px;text-align: center;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['description_of_risk'].'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="padding: 10px;border: 1px solid;">
  <table>
  <tr>
  <td style="width:40%;padding: 7px;border: 1px solid;border-left: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Items Covered</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Contract <br>Value</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Sum Insured <br>(in TZS)</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Premium <br>(in TZS)</p>
  </td>
  </tr>';
  $bulder = $this->db->table('tbl_insurance_sub_type');
  $row = $bulder->getWhere(['id' => $risknote['fk_insurance_type_id']])->getRowArray();
  if ($row['main'] == 1) {
    $bulder = $this->db->table('insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $risknote['id']])->getResultArray();
  }elseif ($row['main'] == 2) {
    $bulder = $this->db->table('vehicle_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $risknote['id']])->getResultArray();
  } elseif ($row['main'] == 3) {
    $bulder = $this->db->table('life_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $risknote['id']])->getResultArray();
  }
  $sum['sum_insured'] = 0;
  $sum['premium'] = 0;
 // $key['premium'] = 0;
        //echo "<pre>"; print_r($res);exit;
  foreach ($res as $key) {
    if(empty($key['premium']))
    {
      $key['premium'] = 0;
    }
    $html .= '<tr>
    <td style="width:40%;padding: 7px;border: 1px solid;border-left: none;">
    <p style="margin: auto;font-size: 16px;font-weight: bold;">'.$risknote['insurance_type_name'].'</p>
    <p style="margin: auto;font-size: 16px;">'.$risknote['description_of_risk'].'</p>
    </td>
    <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;">
    <p style="margin: auto;font-size: 16px;"> 0.00</p>
    </td>
    <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;">
    <p style="margin: auto;font-size: 16px;">'.$sum['sum_insured'].'</p>
    </td>
    
    <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-right: none;">
    <p style="margin: auto;font-size: 16px;">'.$key['premium'].'</p>
    </td>
    
    </tr>';
    $sum['sum_insured'] = $sum['sum_insured']+$key['sum_insured'];
    $sum['premium'] = $sum['premium']+$key['premium'];
  }
       //   echo "<pre>"; print_r($risknote); exit;
  if(empty($risknote['vat_amount']))
  {
    $risknote['vat_amount'] = 0;
  }
  $html .= '<tr>
  <td style="width:40%;padding: 7px;border: 1px solid;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Total</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;"> 0.00</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-left: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">'.$sum['sum_insured'].'</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">'.$sum['premium'].'</p>
  </td>
  </tr>
  <tr>
  <td colspan="3" style="width:40%;padding: 7px;border: 1px solid;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">VAT Premium</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;"> '.$risknote['vat_amount'].'</p>
  </td>
  </tr>
  <tr>
  <td colspan="3" style="width:40%;padding: 7px;border: 1px solid;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Total Premium</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;"> '.($sum['premium'] +  $risknote['vat_amount']).'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="padding: 10px;">
  <table>
  <tr>
  <td rowspan="3" style="width:15%;height:100px;border: 1px solid;text-align: center;">
  <p style="font-size: 16px;font-weight: bold;"> Scan QR <br> code to <br>Validate</p>
  </td>
  <td rowspan="3" style="width:3%;"></td>
  <td rowspan="3" style="width:15%;height:100px;border: 1px solid;text-align: center;">
  <img src="'.base_url('public/assets/images/qrcode').'/qrcode.png" alt="" style="height:90px;">
  </td>
  <td rowspan="3" style="width:3%;">  </td>
  <td rowspan="3" style="width:15%;height:100px;border: 1px solid;text-align: center;">
  <p style="font-size: 16px;font-weight: bold;"> Mulika <br> Alama <br>Kuhakikisha</p>
  </td>
  <td rowspan="3" style="width:3%;"></td>
  <td rowspan="3" style=""></td>
  <td style="padding-top: 0px;text-align:right;width:15%">
  <p style="font-size: 14px;font-weight: bold;"> Date of Issue :</p>
  </td>
  <td style="width:33%;padding: 4px;text-align:right;">
  <p style="font-size: 14px;font-weight: bold;"> ISSUED BY, VIRAL THAKER</p>
  </td>
  </tr>
  <tr>
  <td style="border-bottom: 1px solid;padding-top: 0px;width:50px;">
  <p style="font-size: 14px;">'.date("d-M-Y").'</p>
  </td>
  <td style="width:20px;padding: 4px;">

  </td>
  </tr>
  <tr>
  <td style="padding-top: 0px;">
  </td>
  <td style="width:20px;padding: 4px;text-align:right;">
  <p style="font-size: 13px;font-weight: bold;"></p>
  </td>
  </tr>
  <tr>
  <td colspan="8" style="padding-top: 0px;">
  </td>
  <td style="width:20px;padding: 4px;padding-bottom: 40px;text-align:right;">
  <p style="font-size: 13px;font-weight: bold;">Authorized Signatory</p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="border: 1px solid;text-align: center;">
  <img src="'.base_url('public/assets/images/Brokeraddress').'/addreslogo.png" alt="" style="height:120px;">
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="border: 1px solid;text-align: center;">
  <p style="font-size: 15px;">P.O. Box 871, Mtendeni Street, Dar es salaam, Tanzania, City: DarEsSalaam</p>
  <p style="font-size: 15px;">Tel: 255 22 2126484 | 2138837 | 211 0918 | Fax: 2112504 | Email: info@milmar.co.tz</p>
  </td>
  </tr>
  </table>
  ';

  $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
    // header('Content-Type: application/pdf',charset=utf-8);
  $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td width="75%"><p style="font-size: 11px;">Powered by ITL (Imatic Technologies Limited) from Smart Policy System</p></td>
    <td width="25%" style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');
  $mpdf->WriteHTML($html);
  $filename = 'RISKNOTE-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/risknote/REPORT-'.$filename);
    // $mpdf->Output();
  return redirect()->to(base_url('public/pdf/risknote/REPORT-'.$filename));
}
public function risknote($id)
{
  $session = session();
  if (!isset($_SESSION['userdata'])) {
			// return redirect()->to(site_url('auth'));
  }

  $M_quotation = new Models\QuotationModel();
  $M_quotation->select('insurance_quotation.*,branch_details.branch_name,clients.client_name,clients.title,insurance_company.insurance_company,capture_receipt.risk_note_no');
  $M_quotation->select('tbl_insurance_sub_type.name as insurance_type');
  $M_quotation->join('branch_details', 'branch_details.id = insurance_quotation.fk_branch_id','left');
  $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
  $M_quotation->join('capture_receipt', 'capture_receipt.quot_id = insurance_quotation.id');
  $M_quotation->join('tbl_insurance_sub_type', 'tbl_insurance_sub_type.id = insurance_quotation.fk_insurance_type_id');
  $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
  $risknote = $M_quotation->where(['insurance_quotation.id'=>$id])->first();
   //echo "<pre>"; print_r($risknote); exit;
  require_once FCPATH.'public/mpdf/autoload.php';
  $html = '<style>
  p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td class="full" style="border: 1px solid;padding: 5px;">
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo.png" alt="" style="height:80px;margin: 10px 0;">
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo2.png" alt="" style="float: right;height:80px;margin: 10px 0 10px 200px;">
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding:5px;text-align: center;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">INTERIM COVER NOTE</p>
  </td>
  </tr>
  <tr>
  <td class="full" style="border: 1px solid;padding:3px;text-align: center;">
  <table>
  <tr>
  <td style="width:180px;padding: 4px;">
  <p style="margin: auto;font-size: 14px;font-weight: bold;">RISK NOTE NO :</p>
  </td>
  <td style="width:150px;border: 1px solid;padding:4px;text-align: center;">
  <p style="margin: auto;font-size: 14px;font-weight: bold;">'.$risknote['risk_note_no'].'</p>
  </td>
  <td style="padding: 4px;">
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td rowspan="2" style="width:150px;border: 1px solid;padding:2px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Insured Name</p>
  </td>
  <td rowspan="2" style="width:300px;border: 1px solid;padding:2px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['client_name'].'</p>
  </td>
  <td style="border: 1px solid;padding:2px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Cover Note No</p>
  </td>
  <td style="border: 1px solid;padding:2px;">
  <p style="margin: auto;font-size: 12px;">MLCLG0003762</p>
  </td>
  </tr>

  <tr>
  <td style="border: 1px solid;padding: 5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Policy No</p>
  </td>
  <td style="border: 1px solid;padding: 5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['policy_no'].'</p>
  </td>
  </tr>
  <tr>
  <td style="width:150px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Insurance Type</p>
  </td>
  <td style="width:300px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['insurance_type'].'</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Debit No</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['debitnoteno'].'</p>
  </td>
  </tr>
  <tr>
  <td style="width:150px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Account</p>
  </td>
  <td style="width:300px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['title'].' '.$risknote['client_name'].'</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">File No</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['file_no'].'</p>
  </td>
  </tr>
  <tr>
  <td rowspan="2" style="width:150px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Address</p>
  </td>
  <td rowspan="2" style="width:300px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['address'].'</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Tax Invoice No</p>
  </td>
  <td style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">MFRI36290</p>
  </td>
  </tr>
  <tr>
  <td colspan="2" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;">Insurer Name </p>
  <p style="margin: auto;font-size: 11px;">'.$risknote['insurance_company'].' </p>
  </td>
  </tr>
  <tr>
  <td style="width:150px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">Cover Period From</p>
  </td>
  <td colspan="3" style="width:300px;border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.date("d-M-Y",strtotime($risknote['date_from'])).' 12:00AM To '.date("d-M-Y",strtotime($risknote['date_to'])).'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="width:50%;padding: 4px;border: 1px solid;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">DETAILS OF COVERAGE</p>
  </td>
  <td style="width:50%;border: 1px solid;padding:4px;text-align: center;">
  <p style="margin: auto;font-size: 12px;font-weight: bold;">DESCRIPTION OF RISK</p>
  </td>
  </tr>
  <tr>
  <td style="width:50%;padding: 4px;border: 1px solid;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['covering_details'].'</p>
  </td>
  <td style="width:50%;border: 1px solid;padding:4px;text-align: center;">
  <p style="margin: auto;font-size: 12px;">'.$risknote['description_of_risk'].'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="padding: 10px;border: 1px solid;">
  <table>
  <tr>
  <td style="width:40%;padding: 7px;border: 1px solid;border-left: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Items Covered</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Contract <br>Value</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Sum Insured <br>(in TZS)</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Premium <br>(in TZS)</p>
  </td>
  </tr>';
  $bulder = $this->db->table('tbl_insurance_sub_type');
  $row = $bulder->getWhere(['id' => $risknote['fk_insurance_type_id']])->getRowArray();
  if ($row['main'] == 1) {
    $bulder = $this->db->table('insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $risknote['id']])->getResultArray();
  }elseif ($row['main'] == 2) {
    $bulder = $this->db->table('vehicle_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $risknote['id']])->getResultArray();
  } elseif ($row['main'] == 3) {
    $bulder = $this->db->table('life_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $risknote['id']])->getResultArray();
  }
  $sum['sum_insured'] = 0;
  $sum['premium'] = 0;
     //   echo "<pre>"; print_r($res);exit;
  foreach ($res as $key) {
       $html .= '<tr>
    <td style="width:40%;padding: 7px;border: 1px solid;border-left: none;">
    <p style="margin: auto;font-size: 16px;font-weight: bold;">'.$risknote['insurance_type'].'</p>
    <p style="margin: auto;font-size: 16px;">'.$risknote['description_of_risk'].'</p>
    </td>
    <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;">
    <p style="margin: auto;font-size: 16px;"> 0.00</p>
    </td>
    <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;">
    <p style="margin: auto;font-size: 16px;">'.$sum['sum_insured'].'</p>
    </td>
    <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-right: none;">
    <p style="margin: auto;font-size: 16px;">'.$key['premium'].'</p>
    </td>
    </tr>';
    $sum['sum_insured'] = $sum['sum_insured']+$key['sum_insured'];
    $sum['premium'] = $sum['premium']+$key['premium'];
  }
          // echo "<pre>"; print_r($risknote); print_r($res); exit;
  $html .= '<tr>
  <td style="width:40%;padding: 7px;border: 1px solid;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Total</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;"> 0.00</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-left: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">'.$sum['sum_insured'].'</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">'.$sum['premium'].'</p>
  </td>
  </tr>
  <tr>
  <td colspan="3" style="width:40%;padding: 7px;border: 1px solid;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">VAT Premium</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;"> '.$risknote['vat_amount'].'</p>
  </td>
  </tr>
  <tr>
  <td colspan="3" style="width:40%;padding: 7px;border: 1px solid;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">Total Premium</p>
  </td>
  <td style="width:20%;padding: 7px;border: 1px solid;text-align: right;border-left: none;border-right: none;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;"> '.($sum['premium'] + $risknote['vat_amount']).'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="padding: 10px;">
  <table>
  <tr>
  <td rowspan="3" style="width:15%;height:100px;border: 1px solid;text-align: center;">
  <p style="font-size: 16px;font-weight: bold;"> Scan QR <br> code to <br>Validate</p>
  </td>
  <td rowspan="3" style="width:3%;"></td>
  <td rowspan="3" style="width:15%;height:100px;border: 1px solid;text-align: center;">
  <img src="'.base_url('public/assets/images/qrcode').'/qrcode.png" alt="" style="height:90px;">
  </td>
  <td rowspan="3" style="width:3%;">  </td>
  <td rowspan="3" style="width:15%;height:100px;border: 1px solid;text-align: center;">
  <p style="font-size: 16px;font-weight: bold;"> Mulika <br> Alama <br>Kuhakikisha</p>
  </td>
  <td rowspan="3" style="width:3%;"></td>
  <td rowspan="3" style=""></td>
  <td style="padding-top: 0px;text-align:right;width:15%">
  <p style="font-size: 14px;font-weight: bold;"> Date of Issue :</p>
  </td>
  <td style="width:33%;padding: 4px;text-align:right;">
  <p style="font-size: 14px;font-weight: bold;"> ISSUED BY, VIRAL THAKER</p>
  </td>
  </tr>
  <tr>
  <td style="border-bottom: 1px solid;padding-top: 0px;width:50px;">
  <p style="font-size: 14px;">'.date("d-M-Y").'</p>
  </td>
  <td style="width:20px;padding: 4px;">

  </td>
  </tr>
  <tr>
  <td style="padding-top: 0px;">
  </td>
  <td style="width:20px;padding: 4px;text-align:right;">
  <p style="font-size: 13px;font-weight: bold;"></p>
  </td>
  </tr>
  <tr>
  <td colspan="8" style="padding-top: 0px;">
  </td>
  <td style="width:20px;padding: 4px;padding-bottom: 40px;text-align:right;">
  <p style="font-size: 13px;font-weight: bold;">Authorized Signatory</p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="border: 1px solid;text-align: center;">
  <img src="'.base_url('public/assets/images/Brokeraddress').'/addreslogo.png" alt="" style="height:120px;">
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="border: 1px solid;text-align: center;">
  <p style="font-size: 15px;">P.O. Box 871, Mtendeni Street, Dar es salaam, Tanzania, City: DarEsSalaam</p>
  <p style="font-size: 15px;">Tel: 255 22 2126484 | 2138837 | 211 0918 | Fax: 2112504 | Email: info@milmar.co.tz</p>
  </td>
  </tr>
  </table>
  ';

  $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
    // header('Content-Type: application/pdf',charset=utf-8);
  $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td width="75%"><p style="font-size: 11px;">Powered by ITL (Imatic Technologies Limited) from Smart Policy System</p></td>
    <td width="25%" style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');
  $mpdf->WriteHTML($html);
  $filename = 'RISKNOTE-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/risknote/REPORT-'.$filename);
    // $mpdf->Output();
  return redirect()->to(base_url('public/pdf/risknote/REPORT-'.$filename));
}
public function debitnote($id)
{
  $session = session();
  if (!isset($_SESSION['userdata'])) {
  			// return redirect()->to(site_url('auth'));
  }
  $M_quotation = new Models\QuotationModel();
  $M_quotation->select('insurance_quotation.*,branch_details.branch_name,clients.client_name,clients.title,insurance_company.insurance_company,capture_receipt.risk_note_no');
  $M_quotation->select('tbl_insurance_sub_type.name as insurance_type');
  $M_quotation->join('branch_details', 'branch_details.id = insurance_quotation.fk_branch_id','left');
  $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
  $M_quotation->join('capture_receipt', 'capture_receipt.quot_id = insurance_quotation.id');
  $M_quotation->join('tbl_insurance_sub_type', 'tbl_insurance_sub_type.id = insurance_quotation.fk_insurance_type_id');
  $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
  $debitnote = $M_quotation->where(['insurance_quotation.id'=>$id])->first();
    // echo "<pre>"; print_r($debitnote); exit;
  require_once FCPATH.'public/mpdf/autoload.php';
  $html = '<style>
  p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td style="border: 1px solid;padding: 5px;">
  <img src="'.base_url('public/assets/images/Brokeraddress').'/ric.png" alt="" style="height:110px;margin: 10px 0;">
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;padding:5px;text-align: center;">
  <p style="margin: auto;font-size: 16px;font-weight: bold;">TAX INVOICE</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>Tax Invoice No : </b>RICL121735</p>
  </td>
  <td width="50%" style="border: 1px solid;padding:5px;text-align: right;border-left:none;">
  <p style="margin: auto;font-size: 12px;"><b>Date : </b>'.date("d-M-Y").'</p>
  </td>
  </tr>
  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;border-bottom:none;">
  <p style="margin: auto;font-size: 12px;"><b>Client Name : </b>'.$debitnote['title'].' '.$debitnote['client_name'].'</p>
  </td>
  <td width="50%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;"><b>Cover Period : </b>'.date("d-M-Y",strtotime($debitnote['date_from'])).' 12:00AM To '.date("d-M-Y",strtotime($debitnote['date_to'])).'</p>
  </td>
  </tr>
  <tr>
  <td width="50%" rowspan="2" style="border: 1px solid;padding:5px;border-top:none;">
  <p style="margin: auto;font-size: 12px;"><b>Address : </b></p>
  <p style="margin: auto;font-size: 12px;">'.$debitnote['address'].'</p>
  </td>
  <td width="50%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;"><b>Intermediary Name / Branch Name : </b></p>
  <p style="margin: auto;font-size: 12px;">Milmar Insurance Consultants Ltd / Head Office</p>
  </td>
  </tr>
  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;"><b>Intermediary Debit Note # : </b>'.$debitnote['debitnoteno'].'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;"><b>COVERING DETAILS </b></p>
  </td>
  <td width="50%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;"><b>DESCRIPTION OF RISK </b></p>
  </td>
  </tr>
  <tr>
  <td width="50%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$debitnote['covering_details'].'</p>
  </td>
  <td width="50%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$debitnote['description_of_risk'].'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td width="64%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;"><b>Description </b></p>
  </td>
  <td width="18%" style="border: 1px solid;padding:5px;text-align: right;">
  <p style="margin: auto;font-size: 12px;"><b>Sum Insured </b></p>
  </td>
  <td width="18%" style="border: 1px solid;padding:5px;text-align: right;">
  <p style="margin: auto;font-size: 12px;"><b>Total Amount Payable (in TZS) </b></p>
  </td>
  </tr>';
  $bulder = $this->db->table('tbl_insurance_sub_type');
  $row = $bulder->getWhere(['id' => $debitnote['fk_insurance_type_id']])->getRowArray();
  if ($row['main'] == 1) {
    $bulder = $this->db->table('insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $debitnote['id']])->getResultArray();
  }elseif ($row['main'] == 2) {
    $bulder = $this->db->table('vehicle_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $debitnote['id']])->getResultArray();
  } elseif ($row['main'] == 3) {
    $bulder = $this->db->table('life_insurance_class_insert');
    $res = $bulder->getWhere(['quot_id' => $debitnote['id']])->getResultArray();
  }
  $sum['sum_insured'] = 0;
  $sum['premium'] = 0;
 //  echo "<pre>";  print_r($res); exit;
  foreach ($res as $key) {
    $html .= '<tr>
    <td width="64%" style="border: 1px solid;padding:5px;">
    <p style="margin: auto;font-size: 12px;">'.$key['description'].'</p>
    </td>
    <td width="18%" style="border: 1px solid;padding:5px;text-align: right">
    <p style="margin: auto;font-size: 12px;">'.$key['sum_insured'].'</p>
    </td>
    <td width="18%" style="border: 1px solid;padding:5px;text-align: right">
    <p style="margin: auto;font-size: 12px;">'.$key['total_premium'].'</p>
    </td>
    </tr>';
    $sum['sum_insured'] = $sum['sum_insured']+$key['sum_insured'];
    $sum['premium'] = $sum['premium']+$key['total_premium'];
  }
  $html .= '</table>
  <table>
  <tr>
  <td style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>Total Premium </b></p>
  </td>
  <td style="border: 1px solid;padding:5px;border-left:none;text-align: right">
  <p style="margin: auto;font-size: 12px;"><b> '.$sum['sum_insured'].' </b></p>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>VAT Premium </b></p>
  </td>
  <td style="border: 1px solid;padding:5px;border-left:none;text-align: right">
  <p style="margin: auto;font-size: 12px;"><b>  '.$sum['premium'].' </b></p>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;padding:5px;border-right:none;">
  <p style="margin: auto;font-size: 12px;"><b>Total Payable </b></p>
  </td>
  <td style="border: 1px solid;padding:5px;border-left:none;text-align: right;">
  <p style="margin: auto;font-size: 12px;"><b> '.$debitnote['total_receivable'].' </b></p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td width="30%" style="border: 1px solid;padding-bottom:25px;border-right:none;">
  <table>
  <tr>
  <td style="padding:2px;"><p style="margin: auto;font-size: 9px;"><b><i>FOR TRA PURPOSE :</i></b></p></td>
  </tr>
  <tr>
  <td style="padding:5px;text-align: right;"><p style="margin: auto;font-size: 10px;"><b><i>Gross Amount : TZS '.$debitnote['tax_total_premium'].'</i></b></p></td>
  </tr>
  <tr>
  <td style="padding:5px;text-align: right;"><p style="margin: auto;font-size: 10px;"><b><i>VAT : TZS '.$debitnote['vat_amount'].'</i></b></p></td>
  </tr>
  <tr>
  <td style="padding:5px;text-align: right;"><p style="margin: auto;font-size: 10px;"><b><i>Total Amount : TZS '.$debitnote['total_receivable'].'</i></b></p></td>
  </tr>
  </table>
  </td>
  <td style="border: 1px solid;padding:5px;border-left:none;border-right:none;">
  </td>
  <td width="110px" style="border: 1px solid;padding:5px;border-left:none;text-align:center;">
  <img src="'.base_url('public/assets/images/qrcode').'/qrcode.png" alt="" style="height:90px;">
  <p style="margin: auto;font-size: 9px;"><b><i>62E35F21671</i></b></p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="padding:4px;border: 1px solid;"><p style="margin: auto;font-size: 12px;"><b>TIN: 100-638-444, VRN: 40-004-455-C</b></p></td>
  </tr>
  <tr>
  </tr>
  <tr>
  <td style="padding:5px;border: 1px solid;border-bottom:none;">
  <p style="margin: auto;font-size: 10px;">A. I&M Bank (T) Limited A/C</p>
  <p style="margin: auto;font-size: 10px;">Tshs - 010006941101 Swift Code: IMBLTZTZ</p>
  <p style="margin: auto;font-size: 10px;">USD - 010006940111 Swift Code: IMBLTZTZ</p>
  </td>
  </tr>
  <tr>
  <td style="padding:5px;border: 1px solid;border-bottom:none;border-top:none;">
  <p style="margin: auto;font-size: 10px;">A. I&M Bank (T) Limited A/C</p>
  <p style="margin: auto;font-size: 10px;">Tshs - 010006941101 Swift Code: IMBLTZTZ</p>
  <p style="margin: auto;font-size: 10px;">USD - 010006940111 Swift Code: IMBLTZTZ</p>
  </td>
  </tr>
  <tr>
  <td style="padding:5px;border: 1px solid;border-top:none;">
  <p style="margin: auto;font-size: 10px;">C. EXIM Bank (T) Limited A/C</p>
  <p style="margin: auto;font-size: 10px;">Tshs - 0300551007 Swift Code: EXTNTZTZ</p>
  <p style="margin: auto;font-size: 10px;">USD - 0300551550 Swift Code: EXTNTZTZ</p>
  </td>
  </tr>
  <tr>
  <td style="padding:5px;border: 1px solid;border-bottom:none;">
  <p style="margin: auto;font-size: 9px;font-weight: bold;">1. When referring to this bill please quote the policy number</p>
  <p style="margin: auto;font-size: 9px;font-weight: bold;">2. Cheques should be crossed and made payable to reliance insurance company (t) ltd.</p>
  <p style="margin: auto;font-size: 9px;font-weight: bold;">3. An official receipt should be obtained upon payment.</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="padding:5px;border-left:1px solid;border-bottom:1px solid;">
  <p style="margin: auto;font-size: 9px;font-weight: bold;"></p>
  </td>
  <td style="width:300px;padding:5px;padding-bottom:90px;text-align:center;border-right:1px solid;border-bottom:1px solid;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;">This is a computer generated Tax </p>
  <p style="margin: auto;font-size: 11px;font-weight: bold;">Invoice and no signature is required </p>
  </td>
  </tr>
  <tr>
  <td colspan="2" style="padding:5px;border:1px solid;text-align:center;">
  <p style="margin: auto;font-size: 12px;">Reliance House, Plot No 356, UN Road, Upanga, P.O. Box 9826</p>
  <p style="margin: auto;font-size: 12px;">Tel: 2120088-90,</p>
  </td>
  </tr>
  </table>
  ';

  $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
    // header('Content-Type: application/pdf',charset=utf-8);
  $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td width=""><p style="font-size: 11px;">Powered from Smart Policy Insurance System</p></td>
    <td width="" style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');
  $mpdf->WriteHTML($html);
  $filename = 'DEBITNOTE-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/debitnote/REPORT-'.$filename);
    // $mpdf->Output();
  return redirect()->to(base_url('public/pdf/debitnote/REPORT-'.$filename));
}
public function provisionalbatch($id)
{
  $session = session();
  if (!isset($_SESSION['userdata'])) {
			// return redirect()->to(site_url('auth'));
  }
  $M_provisionalbatch = new Models\ProvisionalBatchTaxInvoicesModel();
  $M_provisionalbatch->select('provisional_batch_tax_invoices.*,currency.name as ccy,insurance_company.insurance_company,insurance_company.company_address');
  $M_provisionalbatch->join('currency', 'currency.id = provisional_batch_tax_invoices.currency_id','left');
  $M_provisionalbatch->join('insurance_company', 'insurance_company.id = provisional_batch_tax_invoices.insurance_company_id','left');
  $provisionalbatch = $M_provisionalbatch->where(['provisional_batch_tax_invoices.id'=>$id])->first();
    // echo "<pre>"; print_r($provisionalbatch); exit;
  require_once FCPATH.'public/mpdf/autoload.php';
  $html = '<style>
  p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td width="34%" style="border: 1px solid;padding:5px;">
  <p style="font-size: 12px;"><b>Tax Invoice :</b> '.$provisionalbatch['tax_invoice_no'].'</p>
  <p style="font-size: 12px;"><b>Currency :</b> '.$provisionalbatch['ccy'].'</p>
  </td>
  <td width="32%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;"><b>ETR No :</b> '.$provisionalbatch['etr_no'].'</p>
  </td>
  <td width="34%" style="border: 1px solid;padding:5px;">
  <p style="margin: auto;font-size: 12px;"><b>ETR Date :</b> '.date("d-M-Y",strtotime($provisionalbatch['date'])).'</p>
  <p style="margin: auto;font-size: 12px;"><b>Exchange Rate :</b> '.$provisionalbatch['x_rate'].'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td width="80px" style="border-left: 1px solid;padding:5px;">
  <p style="font-size: 12px;"><b>To :</b></p>
  </td>
  <td style="padding:5px;">
  <p style="margin: auto;font-size: 12px;">'.$provisionalbatch['insurance_company'].'</p>
  </td>
  <td width="250px" style="padding:5px;border-right: 1px solid;">
  <p style="margin: auto;font-size: 12px;">TIN : 128-192-271,VRN :40-022514-X</p>
  </td>
  </tr>
  <tr>
  <td width="80px" style="border-left: 1px solid;padding:5px;">
  <p style="font-size: 12px;"><b>Address :</b></p>
  </td>
  <td colspan="2" style="padding:5px;border-right: 1px solid;">
  <p style="margin: auto;font-size: 12px;">'.$provisionalbatch['company_address'].',
  TanzaniaTelephone: +255 22 2922337/338 | Email : info@mayfair.co.tz | Website: www.mayfair.co.tz,</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <th style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">Debit note/Credit Note</p></th>
  <th style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">Receipt No - Policy No</p></th>
  <th style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">Customer Name</p></th>
  <th style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">Insurance Type</p></th>
  <th style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">Cover Period</p></th>
  <th style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">Comm Rate</p></th>
  <th style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">Total Premium (in TZS)</p></th>
  <th style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">Commission</p></th>
  </tr>';
  $M_quotation = new Models\QuotationModel();
  $M_quotation->select('insurance_quotation.*,clients.client_name,tbl_insurance_sub_type.name as insurance_type');
  $M_quotation->join('branch_details', 'branch_details.id = insurance_quotation.fk_branch_id','left');
  $M_quotation->join('clients', 'clients.id = insurance_quotation.fk_client_id','left');
  $M_quotation->join('insurance_company', 'insurance_company.id = insurance_quotation.fk_insurance_company_id','left');
  $M_quotation->join('tbl_insurance_sub_type', 'tbl_insurance_sub_type.id = insurance_quotation.fk_insurance_type_id','left');
  $quotation = $M_quotation->whereIn('insurance_quotation.id',explode(',',$provisionalbatch['quot_ids']))->findAll();
    // echo "<pre>"; print_r($provisionalbatch); print_r($quotation); exit;
  $sum['broker_commission'] = 0;
  $sum['vat_on_commission'] = 0;
  foreach ($quotation as $key) {
    $html.='<tr><td style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">'.$key['debitnoteno'].'</p></td>
    <td style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">'.$key['quotation_id'].'
    017</p></td>
    <td style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">'.$key['client_name'].'</p></td>
    <td style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">'.$key['insurance_type'].'</p></td>
    <td style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">'.date("d-M-Y",strtotime($key['date_from'])).' <br>
    '.date("d-M-Y",strtotime($key['date_to'])).'</p></td>
    <td style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">'.$key['commission_percentage'].'</p></td>
    <td style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">'.$key['total_receivable'].'</p></td>
    <td style="border: 1px solid;padding:5px;"><p style="font-size: 11px;">'.$key['broker_commission'].'</p></td></tr>';
    $sum['broker_commission'] = $sum['broker_commission'] + $key['broker_commission'];
    $sum['vat_on_commission'] = $sum['vat_on_commission'] + $key['vat_on_commission'];
  }
  $html.='</table>';
    // echo $html;exit();
  $html.='<table>
  <tr>
  <td style="border: 1px solid;border-right:none;padding: 5px;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;">COMMISSION</p>
  </td>
  <td style="border: 1px solid;border-left:none;padding:5px;text-align:right;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;">'.$sum['broker_commission'].'</p>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;border-right:none;padding: 5px;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;">VAT ON COMMISSION</p>
  </td>
  <td style="border: 1px solid;border-left:none;padding:5px;text-align:right;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;"> '.$sum['vat_on_commission'].'</p>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;border-right:none;padding: 5px;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;">TOTAL COMMISSION</p>
  </td>
  <td style="border: 1px solid;border-left:none;padding:5px;text-align:right;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;"> '.($sum['broker_commission'] + $sum['vat_on_commission']).'</p>
  </td>
  </tr>
  <tr>
  <td style="border: 1px solid;border-right:none;padding: 5px;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;">TOTAL COMMISSION (in TZS)</p>
  </td>
  <td style="border: 1px solid;border-left:none;padding:5px;text-align:right;">
  <p style="margin: auto;font-size: 11px;font-weight: bold;"> '.($sum['broker_commission'] + $sum['vat_on_commission']).'</p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="border: 1px solid;height:20px;"></td>
  </tr>
  <tr>
  <td style="border: 1px solid;padding:5px;height:150px">
  <table>
  <tr>
  <td style=""></td>
  <td width="200px" style="border-top: 1px solid;text-align:right;">
  <p style="margin: auto;font-size: 9px;font-weight: bold;">For, Milmar Insurance Consultants Ltd</p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>';

  $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
    // header('Content-Type: application/pdf',charset=utf-8);
  $mpdf->SetHTMLHeader('<table>
    <tr>
    <td style="border: 1px solid;border-right:none;padding: 5px;">
    <img src="'.base_url('public/assets/images/Brokerlogo').'/logo.png" alt="" style="height:80px;margin: 10px 0;">
    </td>
    <td style="border: 1px solid;border-left:none;padding:5px;text-align:right;">
    <img src="'.base_url('public/assets/images/Brokerlogo').'/logo2.png" alt="" style="float: right;height:80px;margin: 10px 0 10px 200px;">
    </td>
    </tr>
    <tr>
    <td colspan="2" style="border: 1px solid;padding:5px;text-align: center;">
    <p style="margin: auto;font-size: 14px;font-weight: bold;">Provisional Batch Tax Invoice</p>
    </td>
    </tr>
    </table>');

  $mpdf->AddPage('','','','','',10,10,47);
  $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td><p style="font-size: 11px;">Powered by ITL (Imatic Technologies Limited)</p></td>
    <td style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');
  $mpdf->WriteHTML($html);
  $filename = 'PROVISIONALBATCH-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/provisionalbatch/REPORT-'.$filename);
    // $mpdf->Output();
  return redirect()->to(base_url('public/pdf/provisionalbatch/REPORT-'.$filename));
}
public function creditnote($id)
{
  $session = session();
  if (!isset($_SESSION['userdata'])) {
			// return redirect()->to(site_url('auth'));
  }
  $M_creditnote = new Models\CreditnoteModel();
  $M_creditnote->select('credit_note.*,branch_details.branch_name,insurance_company.insurance_company,currency.name as currency_name,clients.tin,clients.title,clients.address,clients.client_name,clients.mobile_number,clients.email');
  $M_creditnote->join('insurance_company', 'insurance_company.id = credit_note.company_id','left');
  $M_creditnote->join('branch_details', 'branch_details.id = credit_note.branch_id','left');
  $M_creditnote->join('currency', 'currency.id = credit_note.currency_id','left');
  $M_creditnote->join('clients', 'clients.id = credit_note.client_id','left');
  $creditnote = $M_creditnote->where(['credit_note.id'=>$id])->first();
  // echo "<pre>"; print_r($creditnote); exit;
  require_once FCPATH.'public/mpdf/autoload.php';
  $html = '<style>
  p{
    margin: 0;
    font-size: x-large;
  }
  td.full{
    width:100%;
  }
  table{
    width: 100%;
    border-collapse: collapse;
  }
  table tr td{

  }
  table tr td.t-end{
    text-align: left;
  }
  </style>
  <table>
  <tr>
  <td style="border: 1px solid;border-right:none;padding: 5px;">
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo.png" alt="" style="height:80px;margin: 10px 0;">
  </td>
  <td style="border: 1px solid;border-left:none;padding:5px;text-align:right;">
  <img src="'.base_url('public/assets/images/Brokerlogo').'/logo2.png" alt="" style="float: right;height:80px;margin: 10px 0 10px 200px;">
  </td>
  </tr>
  <tr>
  <td colspan="2" style="margin-left:2px;border: 1px solid;padding:10px;text-align: center;background-color:black;color:white;">
  <p style="font-size: 14px;font-weight: bold;">CREDIT NOTE</p>
  </td>
  </tr>
 <tr>
  <td style="border-left:1px solid;padding:6px;">
  <p style="font-size: 14px;"> <b>Credit No. : '.$creditnote['creditnote_no'].'</b> </p>
  </td>
  <td style="text-align: right;border-right:1px solid;padding:6px;">
  <p style="font-size: 14px;"> <b>Date : '.date("d-M-Y").'</b> </p>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <td width="" style="border: 1px solid;padding:3px;">
  <table>
  <tr>
  <td width="" style="padding:3px;"><p style="font-size: 12px;"><b>Client Name :</b>'.$creditnote['title'].'. '.$creditnote['currency_name'].'</p></td>
  </tr>
  <tr>
  <td width="" style="padding:3px;"><p style="font-size: 12px;"><b>Type : </b>Coporate Public - Others</p></td>
  </tr>
  <tr>
  <td width="" style="padding:3px;"><p style="font-size: 12px;"><b>Address :</b></p></td>
  </tr>
  <tr>
  <td width="" style="padding:3px;"><p style="font-size: 12px;">'.$creditnote['address'].' Mobile: '.explode(",",$creditnote['mobile_number'])[0].',Email : '.explode(",",$creditnote['email'])[0].'</p></td>
  </tr>
  </table>
  </td>
  </tr>
  </table>
  <table>
  <tr>
  <th width="40%" style="border:1px solid;padding:5px;text-align:left;"><p style="font-size:11px;">Description</p></th>
  <th style="border:1px solid;padding:5px;text-align:right;"><p style="font-size:11px;">Net Amount</p></th>
  <th style="border:1px solid;padding:5px;text-align:right;"><p style="font-size:11px;">Insurer Deduct Amount</p></th>
  <th style="border:1px solid;padding:5px;text-align:right;"><p style="font-size:11px;">Insurer Amount</p></th>
  <th style="border:1px solid;padding:5px;text-align:right;"><p style="font-size:11px;">Total Amount (in USD)</p></th>
  </tr>';
  $html.='<tr><td style="border:1px solid;padding:5px;"><p style="font-size:11px;">'.$creditnote['description'].'</p></td>
  <td style="border: 1px solid;padding:5px;text-align:right;"><p style="font-size: 11px;">'.$creditnote['gross_amount'].'</p></td>
  <td style="border: 1px solid;padding:5px;text-align:right;"><p style="font-size: 11px;">'.$creditnote['insurer_deduct_amount'].'</p></td>
  <td style="border: 1px solid;padding:5px;text-align:right;"><p style="font-size: 11px;"></p></td>
  <td style="border: 1px solid;padding:5px;text-align:right;"><p style="font-size: 11px;">'.$creditnote['total_amount'].'</p></td></tr>';
  $html.='<tr>
  <td colspan="3" style="border:1px solid;padding:5px;"><p style="font-weight: bold;font-size:11px;">TOTAL AMOUNT</p></td>
  <td style="border:1px solid;padding:5px;text-align:right;"><p style="font-weight: bold;font-size:11px;"> 0.00</p></td>
  <td style="border:1px solid;padding:5px;text-align:right;"><p style="font-weight: bold;font-size:11px;">'.$creditnote['total_amount'].'</p></td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="border:1px solid;border-bottom:none;padding:5px;"><p style="font-weight:bold;font-size:9px;">TIN: '.$creditnote['tin'].',</p></td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="border-right:1px solid;border-left:1px solid;height:450px;"><p style="font-weight:bold;font-size:9px;"></p></td>
  </tr>
  </table>
  <table>
  <tr>
  <td style="border: 1px solid;padding:5px;height:150px">
  <table>
  <tr>
  <td style=""></td>
  <td style="text-align:right;padding-bottom:90px;"><p style="font-size: 11px;font-weight: bold;">ISSUED BY, MUDATHIR N. DAUD</p></td>
  </tr>
  <tr>
  <td style=""></td>
  <td width="200px" style="border-top: 1px solid;padding-bottom:20px;text-align:right;">
  <p style="font-size: 9px;font-weight: bold;">For, Milmar Insurance Consultants Ltd</p>
  </td>
  </tr>
  </table>
  </td>
  </tr>
  </table>';

  $mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
    // header('Content-Type: application/pdf',charset=utf-8);
  $mpdf->SetHTMLFooter('
    <table width="100%">
    <tr>
    <td><p style="font-size: 11px;">Powered by ITL (Imatic Technologies Limited)</p></td>
    <td style="text-align: right;"><p style="font-size: 11px;">{PAGENO}/{nbpg}</p></td>
    </tr>
    </table>');

  $mpdf->WriteHTML($html);
  $filename = 'CREDITNOTE-'.time().'.pdf';
  $mpdf->Output(FCPATH.'public/pdf/creditnote/REPORT-'.$filename);
    // $mpdf->Output();

  return redirect()->to(base_url('public/pdf/creditnote/REPORT-'.$filename));
}

public function directpayment($id)
{
  $session = session();
  if (!isset($_SESSION['userdata'])) {
   return redirect()->to(site_url('auth'));
 }
 $M_directpayment = new Models\DirectPaymentModel();
 $M_directpayment->select('direct_payment.*,clients.client_name,clients.title,clients.address,clients.tin,clients.vrn,currency.code');
 $M_directpayment->join('clients', 'clients.id = direct_payment.client_id','left');
 $M_directpayment->join('currency', 'currency.id = direct_payment.currency_id','left');
 $direct_payment = $M_directpayment->where(['direct_payment.id'=>$id])->first();
 $bulder = $this->db->table('insurance_quotation');
 $quotation = $bulder->getWhere(['id' => $direct_payment['quot_id']])->getRowArray();
 $bulder = $this->db->table('tbl_insurance_sub_type');
 $insurance = $bulder->getWhere(['id' => $quotation['fk_insurance_type_id']])->getRowArray();
    // echo '<pre>'; print_r($direct_payment); print_r($quotation); print_r($insurance); exit;
 require_once FCPATH.'public/mpdf/autoload.php';
 $html = '<style>
 p{
  margin: 0;
  font-size: x-large;
}
td.full{
  width:100%;
}
table{
  width: 100%;
  border-collapse: collapse;
}
table tr td{

}
table tr td.t-end{
  text-align: left;
}
</style>
<table>
<tr>
<td class="full" style="height: 120px;border: 1px solid;padding: 5px;">
<img src="'.base_url('public/assets/images/Brokeraddress').'/ric.png" alt="" style="height:100px;">
</td>
</tr>
<tr>
<td class="full" style="border: 1px solid;padding:7px;background-color: #000;text-align: center;">
<p style="color: #fff;margin: auto;font-size: 14px;">RECEIPT</p>
</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;">
<table>
<tr>
<td>
<p style="font-size: 12px;"> <b>No/CL : 123456</b> </p>
</td>
<td style="text-align: right;">
<p style="font-size: 12px;"> <b>Date : '.date("d-M-Y").'</b> </p>
</td>
</tr>
</table>
</td>
</tr>
</table>
<table>
<tr>
<td style="border: 1px solid;border-bottom:none;border-right:none;padding:7px;width:130px;">
<p style="font-size: 12px;"> <b>Received From </b> </p>
</td>
<td style="border: 1px solid;padding:7px;border-bottom:none;border-left:none;">
<p style="font-size: 12px;">: '.$direct_payment['title'].'. '.$direct_payment['title'].'</p>
</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;width:130px;border-top:none;border-right:none;">
<p style="font-size: 12px;"> <b>Address </b> </p>
</td>
<td style="border: 1px solid;padding:7px;border-top:none;border-left:none;">
<p style="font-size: 12px;">: '.$direct_payment['address'].'</p>
</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;width:130px;border-bottom:none;border-right:none;">
<p style="font-size: 12px;"> <b>Payment Mode </b> </p>
</td>
<td style="border: 1px solid;padding:7px;border-bottom:none;border-left:none;">
<p style="font-size: 12px;">: '.$direct_payment['mode'].'</p>
</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;width:130px;border-top:none;border-right:none;">
<p style="font-size: 12px;"> <b>Reference No. </b> </p>
</td>
<td style="border: 1px solid;padding:7px;border-top:none;border-left:none;">
<p style="font-size: 12px;">: '.$direct_payment['cheque_reference_no'].'</p>
</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;width:130px;border-bottom:none;border-right:none;">
<p style="font-size: 12px;"> <b>Notes </b> </p>
</td>
<td style="border: 1px solid;padding:7px;border-bottom:none;border-left:none;">
<p style="font-size: 12px;">: '.$direct_payment['notes'].'</p>
</td>
</tr>
</table>
<table>
<tr>
<td style="border: 1px solid;padding:7px;width:30%;border-top:none;border-right:none;">
<table>
<tr>
<td style="padding:3px;">'.$direct_payment['code'].'</td>
<td style="border: 1px solid;padding:3px;">'.$direct_payment['amount'].'</td>
</tr>
</table>
</td>
<td style="border: 1px solid;padding:7px;text-align:center;width:30%;border-top:none;border-left:none;border-right:none;"></td>
<td style="border: 1px solid;padding:7px;text-align:center;width:40%;border-top:none;border-left:none;">
<p style="font-size: 12px;"> <b>This is a computer generated Receipt</b> </p>
<p style="font-size: 12px;"> <b>and no signature is required</b> </p>
</td>
</tr>
</table>
<table>
<tr>
<td style="border: 1px solid;padding:7px;">TZS, ONE HUNDRED EIGHTEEN THOUSAND ONLY</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;font-size:11px;font-weight:bold;">TIN: '.$direct_payment['tin'].', VRN: '.$direct_payment['vrn'].'</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;font-size:11px;font-weight:bold;">The below are allocated Tax Invoice against the above payment:</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;font-size:12px;text-align:center;">Reliance Insurance Company (Tanzania) Limited</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;font-size:13px;">
<table>
<tr>
<th style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">Tax Invoice #</th>
<th style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">Customer Tax <br> Invoice #</th>
<th style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">Insurance Type</th>
<th style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">Currency</th>
<th style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">Gross Premium</th>
<th style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">Paid Amount</th>
<th style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">Balance</th>
</tr>
<tr>
<td style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">26179</td>
<td style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">RICL123669</td>
<td style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">'.$insurance['name'].'</td>
<td style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">'.$direct_payment['code'].'</td>
<td style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;"> '.$quotation['total_receivable'].'</td>
<td style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">'.$direct_payment['amount'].'</td>
<td style="border-bottom: 1px solid;border-top: 1px solid;padding:7px;font-size:11px;">'.$quotation['current_balance'].'</td>
</tr>
</table>
</td>
</tr>
<tr>
<td style="border: 1px solid;padding:7px;font-size:12px;text-align:center;">
<p style="font-size: 12px;"> Reliance House, Plot No 356, UN Road, Upanga, P.O. Box 9826 </p>
<p style="font-size: 12px;"> Tel: 2120088-90, </p>
</td>
</tr>
</table>';
$mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
$mpdf->WriteHTML($html);
$filename = 'QUOTATION-'.time().'.pdf';
$mpdf->Output(FCPATH.'public/pdf/directpayment/REPORT-'.$filename);
return redirect()->to(base_url('public/pdf/directpayment/REPORT-'.$filename));
}

public function send_renewal_email($id)
{
  $session = session();
  if (!isset($_SESSION['userdata'])) {
   return redirect()->to(site_url('auth'));
 }
 require_once FCPATH.'public/mpdf/autoload.php';
 $html = '<style>
 p{
  margin: 0;
  font-size: x-large;
}
td.full{
  width:100%;
}
table{
  width: 100%;
  border-collapse: collapse;
}
table tr td{

}
table tr td.t-end{
  text-align: left;
}
</style>
<table>
<tr>
<td class="full" style="height: 120px;border: none;padding: 5px;text-align: right">
</td>
</tr>
<tr>
<td class="full" style="border-top: 1px solid;padding:7px;text-align: right;">
<p style="font-size: 12px;"> <b>Date : '.date("d-M-Y").'</b> </p>
</td>
</tr>
</table>
<table>
<tr>
<td style="border-bottom: 1px solid;height:170px;padding:7px;">
</td>
<td style="border-bottom: 1px solid;height:170px;padding:7px;">
</td>
</tr>
<tr>
<td style="width:50%;eight:60px;padding:7px;">
<p style="font-size: 12px;"> <b>Covering Details : </b> </p>
</td>
<td style="width:50%;height:60px;padding:7px;">
<p style="font-size: 12px;"> <b>Description of Risk :</b> </p>
</td>
</tr>
</table>
<table>
<tr>
<td style="width:70%;border-bottom: 1px solid;padding:2px;">
<p style="font-size: 12px;"> <b>File No.: </b> </p>
</td>
<td style="width:30%;border-bottom: 1px solid;padding:2px;">
<p style="font-size: 12px;"> <b>Expiry Date :</b> </p>
</td>
</tr>
</table>
<table>
<tr>
<td style="width:250px;border-bottom: 1px solid;padding:5px;padding-bottom:10px;">
<p style="font-size: 12px;"> <b>Cover Details </b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Sum Insured</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Premium</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>VAT Amount</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Total Premium</b> </p>
</td>
</tr>
</table><table>
<tr>
<td style="width:250px;border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Cover Details </b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Monthly Salary</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Annual Salary</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Total Premium</b> </p>
</td>
</tr>
</table>
<table>
<tr>
<td style="width:250px;border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Cover Details </b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Sum Insured</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;padding-bottom:15px;">
<p style="font-size: 12px;"> <b>Premium</b> </p>
</td>
</tr>
</table>
<table>
<tr>
<td style="width:200px;border-bottom: 1px solid;padding:5px;">
<p style="font-size: 12px;"> <b>Cover Details </b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;">
<p style="font-size: 12px;"> <b>Death Sum Assured</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;">
<p style="font-size: 12px;"> <b>Medical Sum Assured</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;">
<p style="font-size: 12px;"> <b>TPD Sum Assured</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;">
<p style="font-size: 12px;"> <b>TTD Sum Assured</b> </p>
</td>
<td style="border-bottom: 1px solid;padding:5px;">
<p style="font-size: 12px;"> <b>Total Premium</b> </p>
</td>
</tr>
</table>
<table>
<tr>
<td style="height:110px;border-bottom: 1px dotted;padding:5px;">
</td>
</tr>
</table>
<table>
<tr>
<td style="width:60%;padding:5px;">
<p style="font-size: 12px;"> <b>TOTAL :</b> </p>
</td>
<td style="padding:5px;">
</td>
</tr>
<tr>
<td style="width:60%;padding:5px;">
</td>
<td style="padding:5px;">
<p style="font-size: 12px;"> <b>VAT Premium :</b> </p>
</td>
<tr>
<td style="width:60%;padding:5px;">
</td>
<td style="padding:5px;">
<p style="font-size: 12px;"> <b>Total Premium :</b> </p>
</td>
</tr>
<tr>
<td style="width:60%;padding:5px;border-bottom: 1px solid;border-top: 1px solid;">
<p style="font-size: 12px;"> <b>TOTAL :</b> </p>
</td>
<td style="padding:5px;border-bottom: 1px solid;border-top: 1px solid;">
</td>
</tr>
<tr>
<td style="width:60%;padding:5px;">
<p style="font-size: 12px;"> <b>TOTAL :</b> </p>
</td>
<td style="padding:5px;">
</td>
</tr>
<tr>
<td style="width:60%;padding:5px;">
</td>
<td style="padding:5px;">
<p style="font-size: 12px;"> <b>VAT Premium :</b> </p>
</td>
<tr>
<td style="width:60%;padding:5px;">
</td>
<td style="padding:5px;">
<p style="font-size: 12px;"> <b>Other Fee :</b> </p>
</td>
</tr>
<tr>
<td style="width:60%;padding:5px;">
</td>
<td style="padding:5px;">
<p style="font-size: 12px;"> <b>Policy Holders Fund :</b> </p>
</td>
</tr>
<tr>
<td style="width:60%;padding:5px;">
</td>
<td style="padding:5px;">
<p style="font-size: 12px;"> <b>Training/Insurance Levy :</b> </p>
</td>
</tr>
<tr>
<td style="width:60%;padding:5px;">
</td>
<td style="padding:5px;">
<p style="font-size: 12px;"> <b>Stamp Duty :</b> </p>
</td>
</tr>
<tr>
<td style="width:60%;padding:5px;">
</td>
<td style="padding:5px;">
<p style="font-size: 12px;"> <b>Total Premium :</b> </p>
</td>
</tr>
</table>';
$mpdf = new \Mpdf\Mpdf(['tempDir' => FCPATH . '/custom/temp/dir/path']);
$mpdf->WriteHTML($html);
$filename = 'QUOTATION-'.time().'.pdf';
$mpdf->Output(FCPATH.'public/pdf/directpayment/REPORT-'.$filename);
return redirect()->to(base_url('public/pdf/directpayment/REPORT-'.$filename));
}
}

?>
