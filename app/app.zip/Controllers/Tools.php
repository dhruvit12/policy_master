<?php namespace App\Controllers;
use CodeIgniter\Controller;
use Config\Email;
use Config\Services;
use App\Models;

class Tools extends BaseController
{
  public function __construct()
	{

	}
	public function index()
	{
    $session = session();
    if (!isset($_SESSION['userdata'])) {
     return redirect()->to(site_url('auth'));
   }
  }
  //   // $M_policyrenewals = new Models\policyrenewalsModel();
  //   // $M_policyrenewals->select('sticker_assignment.*,branch_details.branch_name,insurance_company.insurance_company,vehicle_insure_type.vehicle_insure_name');
  //   // $M_policyrenewals->join('insurance_company', 'insurance_company.id = sticker_assignment.insurance_company_id','left');
  //   // $M_policyrenewals->join('branch_details', 'branch_details.id = sticker_assignment.branch_id','left');
  //   // $M_policyrenewals->join('vehicle_insure_type', 'vehicle_insure_type.id = sticker_assignment.insurance_type','left');
  //   // $data['list'] = $M_policyrenewals->where(['sticker_assignment.is_deleted'=>0])->findAll();
    
  //   $M_client = new Models\ClientModel();
  //   $data['client'] = $M_client->where(['status'=>1,'is_deleted'=>0])->findAll();
  //   $M_branch = new Models\BranchModel();
  //   $data['branches'] = $M_branch->where(['is_active'=>1,'is_deleted'=>0])->findAll();
  //   $data['page']='policyrenewals/list';
  //   // print_r($data); exit;
  //   echo view('templete',$data);
  // }
  public function update_fleet_info()
  {
    $data['page']='tools/update_fleet_info';
    echo view('templete',$data);
  }
  public function search_life_medical_member()
  {
    $data['page']='tools/search_life_medical_member';
    echo view('templete',$data);
  }
  public function download_cover_notes()
  {
    $M_insurancecompany = new Models\InsuranceCompanyModel();
    $data['insurancecompany'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $M_insurancecompany = new Models\ClientModel();
    $data['client'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $M_insurancecompany = new Models\BranchModel();
    $data['branch'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $M_insurancecompany = new Models\Insurance_typeModel();
    $data['insurancetype'] = $M_insurancecompany->where(['is_active'=>1,'is_deleted'=>0])->findAll();
    $data['page']='tools/download_cover_notes';
    echo view('templete',$data);
  }
  public function Download()
  {
    
  }
}

?>
