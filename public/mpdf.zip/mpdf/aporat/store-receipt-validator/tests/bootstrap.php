<?php

// Enable Composer autoloader
/** @var \Composer\Autoload\ClassLoader $autoloader */
require __DIR__.'/../vendor/autoload.php';
